# JPods Agent Bridge Architecture

**Date:** April 30, 2026  
**Scope:** SketchUp Plugin v2.2

This document describes the three new class-based bridge architectures that segment JPods concerns into focused, testable modules:

## Overview: Three Bridges

| Bridge | Agent | Purpose | Startup Validation |
|--------|-------|---------|-------------------|
| **Noelle** | Network Authority | Build, validate, manage FollowMe network | Reads & validates followme.json on startup |
| **Nora** | Vehicle Operations | Track experience, detect patterns | Consolidates per-vehicle logs on demand |
| **Conflict** | Safety Guard | Prevent occupancy/routing violations | Audits placement before acceptance |

Artifact rules:
- `followme.json` is the sole network source of truth.
- `vehicles.json` is the sole startup vehicle source of truth.
- Logs stay separate as standalone `*.log.json` documents and are never folded into startup state files.

---

## 1. Noelle Bridge (Network Authority)

**File:** `jpod_noelle_bridge.rb` (160 lines)

### Classes

#### NoelleNetworkBuilder
Orchestrates building network from `followme.json` `network_definition`:
```ruby
result = JPods::NoelleNetworkBuilder.from_json(model)
# Returns: { ok:, built_segments:, followme_path:, faults: [] }
```

**Workflow:**
1. Load `<model>.followme.json` and extract `network_definition`
2. Prepare connection-point cache (all structures)
3. Build each connection segment (parallel guideways)
4. Open stubs at all structures
5. Export FollowMe JSON

#### NoelleNetworkStructure
Wraps FollowMe JSON as queryable graph:
```ruby
structure = JPods::NoelleNetworkStructure.load(followme_path)
successors = structure.successors('seg_123')
behavior = structure.behavior('seg_123', :end)
summary = structure.summary
# → { lines:, stations:, schema_version:, exported_at: }
```

**O(1) Line Lookup:** Index by id + legacy_id for fast graph queries

#### NoelleNetworkValidator
Comprehensive integrity checks:
```ruby
result = JPods::NoelleNetworkValidator.test_all(followme, trips_dir: trips)
# Returns: { ok:, faults: [] }
```

**Five Core Validation Rules:**
1. Component definitions present + valid naming (S###)
2. All referenced line IDs exist (no disconnects)
3. Endpoint behaviors consistent (origin/terminal/continuing rules)
4. Trip file line IDs exist + trip_id format valid
5. **Platform presence check** — catches platform-loss regression

#### NoelleSafetyGate
Recurring fault monitor:
```ruby
safety_result = JPods::NoelleSafetyGate.check(validation_result)
# Returns: { ok:, faults:, stop_review: boolean }
```

**Policy:**
- Tracks consecutive validation faults
- At threshold (3), sets stop_review flag
- Resets to 0 on successful validation
- Prevents silent corruption accumulation

### Startup Validation (NEW)
Noelle now validates on plugin load:
```ruby
# In main.rb after loading noelle.rb:
noelle_startup = JPods::Noelle.validate_followme_on_startup(model)
if noelle_startup[:faults].any?
  puts "⚠️  Noelle startup warning: FollowMe validation issues"
  noelle_startup[:faults].each { |f| puts "  • #{f}" }
end
```

### Console Tasks (4)
- `build_network_noelle` — Build from JSON + validate
- `validate_network_noelle` — Full integrity check + safety gate
- `inspect_network_structure` — Print summary stats
- `noelle_safety_gate_status` — Show fault streak

---

## 2. Nora Bridge (Vehicle Experience Tracking)

**File:** `jpod_nora_bridge.rb` (200+ lines)

### Classes

#### NoraBridge
Main orchestrator:
```ruby
result = JPods::NoraBridge.consolidate_logs(trips_dir)
# Returns: { ok:, vehicles:, segments:, anomalies:, recommendations: [] }

report = JPods::NoraBridge.status_report(trips_dir)
# Prints human-readable summary
```

#### NoraExperienceLogger
Scan per-vehicle logs and aggregate by segment:
```ruby
experience = NoraExperienceLogger.scan_vehicles(trips_dir)
# Returns: { vehicle_count:, segment_stats: { seg_id => { observations:, counts: } } }
```

**Per-Segment Stats:**
- vibration_count, delay_count, blockage_count, sensor_anomaly_count, merge_delay_count
- total_traversals
- observations[] with per-traversal details

#### NoraAnomalyDetector
Identify recurring patterns:
```ruby
anomalies = NoraAnomalyDetector.find_patterns(
  experience,
  vibration_threshold: 0.5,      # Flag if >50% of traversals
  delay_threshold: 0.6,           # Flag if >60%
  blockage_threshold: 0.4,        # Flag if >40%
  occurrence_threshold: 3         # Minimum traversals for signal
)
```

**Severity Levels:** high (>70% rate), medium (between), low

#### NoraMaintenanceAdvisor
Translate anomalies to actionable recommendations:
```ruby
recommendations = NoraMaintenanceAdvisor.recommend_inspections(anomalies)
# Returns: Array sorted by priority (critical → high → medium → low)
```

**Priorities:** critical, high, medium, low  
**Actions:** Specific field inspection procedures by issue type

### Startup Validation (NEW)
Natalie now validates vehicle placement JSON on load:
```ruby
# In jpod_natalie_bridge.rb on startup:
natalie_startup = JPods::NatalieBridge.validate_vehicle_placement_json(model)
if natalie_startup[:issues].any?
  puts "⚠️  Natalie startup warning: Vehicle placement JSON issues"
  natalie_startup[:issues].each { |issue| puts "  • #{issue}" }
end
```

### Console Tasks (2)
- `consolidate_nora_experience` — Full consolidation + pattern detection
- `nora_experience_status` — Human-readable report with recommendations

### Logging rule
- Runtime and support logs are standalone JSON log documents.
- They do not feed startup placement and do not belong in `vehicles.json`.

---

## 3. Conflict Detector (Safety Guard)

**File:** `jpod_conflict_detector.rb` (250+ lines)

### Methods

#### validate_placement(model, vehicle_inst, target_location)
Before placing vehicle, check for occupancy conflicts:
```ruby
result = JPods::ConflictDetector.validate_placement(model, vehicle, platform)
# Returns: { ok:, complaints: [] }
```

**Checks:**
- All other vehicles within 3m centerpoint-to-centerpoint (personal zone)
- Both vehicles on same segment + closer than 5m (merge conflict)

#### validate_all_occupancy(model)
Audit all vehicle pairs for violations:
```ruby
violations = JPods::ConflictDetector.validate_all_occupancy(model)
# Returns: Array of { severity:, vehicle_a:, vehicle_b:, distance_m:, message: }
```

**Severity:** critical (< 3m), warning (< 5m)

#### validate_natalie_assignments(model)
Check if vehicles match Natalie's trip assignments:
```ruby
disruptions = JPods::ConflictDetector.validate_natalie_assignments(model)
# Returns: Array of { severity:, nora_id:, trip_id:, message: }
```

**Rules:**
- Rule 1: Trip assigned → vehicle must be parked at correct origin
- Rule 2: Manual move after trip assignment = critical disruption

#### audit_state_consistency(model)
Internal vehicle state sanity:
```ruby
inconsistencies = JPods::ConflictDetector.audit_state_consistency(model)
# Returns: Array of { severity:, nora_id:, issue:, message: }
```

**Checks:**
- Assigned trip but no current_line_id
- Negative mm_on_line (distance corruption)
- Parked + current_line_id both set (ambiguous)

#### report_all_conflicts(model)
Comprehensive audit to console:
```ruby
result = JPods::ConflictDetector.report_all_conflicts(model)
# Prints formatted report with severity icons
```

### State Tracking (Vehicle Attributes)
- `trip_id` — Assigned trip identifier
- `trip_assigned_at` — ISO timestamp of assignment
- `last_manual_move_at` — ISO timestamp of move
- `current_line_id` — Segment currently on (empty if parked)

### Defensive Placement Validation
Both `place_vehicle_at_platform()` and `move_nora_to_platform_slot()` now:
1. Call `validate_placement()` before confirming
2. Erase vehicle + print loud complaint if conflict
3. Return error so user knows operation failed

### Console Tasks (4)
- `audit_occupancy_conflicts` — All vehicle pairs < 3m/5m
- `audit_natalie_disruptions` — Trip assignment violations
- `audit_state_consistency` — Internal state corruption
- `full_conflict_audit` — Comprehensive report

---

## Load Order

```ruby
# In main.rb:
noelle
jpod_noelle_bridge
natalie
nora
jpod_nora_bridge
jpod_natalie_bridge
jpod_conflict_detector
```

---

## Validation Policies

### Noelle Startup
```
1. Load followme.json if exists
2. Run NoelleNetworkValidator.test_all()
3. If faults:
   - Print each fault to console
   - Warn user but don't halt plugin
4. Track fault streak (safety gate)
```

### Natalie Startup
```
1. Load <model>.vehicles.json if exists
2. Validate schema:
   - Required fields: model_name, saved_at, vehicles[]
   - Each vehicle: id (template), qty (count), nora_ids[], placements[]
   - Each placement: vehicle_id, station_id, parking_slot, platform_id
3. If missing:
   - Print warning with field list
   - Suggest template structure
4. Continue plugin load (non-blocking)
```

---

## Usage Example: Full Cycle

```ruby
# 1. Build network (Noelle)
result = JPods::NoelleNetworkBuilder.from_json(model)
puts "Built #{result[:built_segments]} segments"

# 2. Validate network (Noelle)
followme = JPods::Noelle.load_map(followme_path)
validation = JPods::NoelleNetworkValidator.test_all(followme, trips_dir: trips)
safety = JPods::NoelleSafetyGate.check(validation)
raise "Stop and review" if safety[:stop_review]

# 3. Place vehicles (Conflict Detector validates placement)
ok, result = JPods::JPodVehicleRuntime.place_vehicle_at_platform(
  model, vehicle_template, origin_platform, destination_platform
)
# Placement rejected if occupancy conflict

# 4. Assign trips (Natalie tracks assignment)
ok, msg = JPods::JPodVehicleRuntime.assign_trip_to_vehicle(model, nora_id, line_sequence)
# Sets trip_id + trip_assigned_at timestamps

# 5. Audit state (Conflict Detector)
result = JPods::ConflictDetector.report_all_conflicts(model)
puts "#{result[:total_issues]} issue(s) found"
```

---

## Design Principles

1. **Focused Responsibility**
   - Noelle: build + validate network
   - Nora: track experience + patterns
   - Conflict: prevent occupancy/routing violations

2. **Fail-Fast, Loud**
   - No silent stacking (3m rule enforced at placement)
   - No quiet Natalie violations (timestamps track manual moves)
   - Loud alerts when rules broken

3. **Stateless Bridges**
   - Class methods (no instance state)
   - Pure queries on JSON/model state
   - Safety gate is only stateful component (tracks fault streak)

4. **Separation of Concerns**
   - Validation (Noelle) ≠ routing (Natalie) ≠ operation (Nora)
   - Each can be tested independently
   - Each can be extended without affecting others

---

## Status (April 30, 2026)

- ✅ Noelle Bridge: Network build + structure + validation + safety gate
- ✅ Nora Bridge: Experience logger + anomaly detector + maintenance advisor
- ✅ Conflict Detector: Occupancy + routing + state consistency checks
- ✅ Startup validation for Noelle
- ✅ Startup validation for Natalie (TODO: see next section)
- ✅ Defensive placement validation in vehicle runtime
- ✅ Console tasks (10 total: 4 Noelle, 2 Nora, 4 Conflict)
- ✅ All syntax validated

---

## Next: Fix Vehicle JSON Schema

See `vehicle_json_schema.md` for corrected format with all required fields.
