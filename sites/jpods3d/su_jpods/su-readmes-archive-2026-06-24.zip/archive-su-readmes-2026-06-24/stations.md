# JPods Station Reference

Consolidated documentation for all station formation types — tagging requirements,
CP detection mechanics, FollowMe integration, vehicle platform rules, and deferred
features. This is the single source of truth for station-specific design decisions.

Last updated: 2026-05-12

---

## Station Formation Types

| Formation ID | Label | Template folder |
|---|---|---|
| `station_solar` | Station (Solar) | `templates/track_formations/station_solar/` |
| `station_line_end` | Station (Line End) | `templates/track_formations/station_line_end/` |
| `JPods_station_container` | Station (Container) | `templates/track_formations/JPods_station_container/` |
| `station_parking` | Station (Parking) | `templates/track_formations/station_parking/` |

All station template files are `model.skp` inside their folder.

---

## Mandatory SketchUp Tags

These three tags must be applied inside **every station `model.skp`** before the formation
is accepted by the plugin. Tag names are exact — case, spaces, and spelling matter.
`jpod_structure_tool.rb` matches with `.downcase ==` — one wrong character silently falls
through to geometry inference, which has proven unreliable.

### `stub_pair`

**Applied to:** Both parallel stub track entities at each external gate.  
A stub is the short track segment that sticks out from the station body at the connection face.  
Each gate has **exactly two stubs** — one per parallel guideway.

**How the plugin uses it:**  
`detect_cps_from_stub_pair_tags` scans for entities on this tag, locates the outer-end
representative point of each, pairs tips ~`DUAL_TRACK_SPACING` (3.5 m) apart, takes the
midpoint, then shifts by `BEAM_WIDTH / 2` (0.25 m) inward across the gate to land on the
true guideway centerline pair midpoint. This is the **primary CP detector**.

**Without it:** falls through to `detect_connection_points_from_endings` or `pair_stubs`
fallback. Both have proven to produce wrong CPs or extra CPs for station geometry.

**Verification:** Console output must include `CPs from stub_pair tags` after Recompute CPs.  
If it says `pair_stubs fallback` or `cap seam scan` — the tag is missing or misnamed.

---

### `dead_end_cap`

**Applied to:** Each removable ending-cap entity at the outer tip of every stub.  
In ene_railroad templates these are `ending` components. Rename or retag them to `dead_end_cap`.

**How the plugin uses it:**  
1. **CP seam datum:** `scan_vertices_excluding_end_caps` skips cap geometry when computing
   the outer-tip representative point for each `stub_pair`. Without this exclusion, the
   outer representative point resolves to the cap tip and shifts the CP outward past the
   real seam.  
2. **Routing:** vehicles must not traverse beyond a capped endpoint. The runtime scans
   `dead_end_cap` origins from all placed structures and blocks guideway transitions past
   capped endpoints — even when a `next_cid` exists in the connection graph.  
3. **Secondary CP detector:** `detect_connection_points_from_endings` (Priority 2 in
   `resolve_connection_points`) uses these entities to detect gate positions when
   `stub_pair` tags are absent.

**Legacy name:** entities still named `ending` or with definition name containing `ending`
trigger a `⚠️ JPods: cap entity still named 'ending'` warning. Rename to `dead_end_cap`.

---

### `platform`

**Applied to:** The loading/unloading siding guideway inside the station body.  
This is the berth track where Noras park and passengers board/alight.

**How the plugin uses it:**  
`detect_platform_guideways_in_defn` scans for this tag at FollowMe export time. Detected
guideways are surfaced as `platform_guideways[]` in each station's block in `followme.json`.
Natalie uses platform positions to route Noras to the correct loading berth.

**Detection priority:** tag `platform` → instance name `platform` → definition name `platform`.  
Tag is preferred. Name is fallback.

**Naming convention for the berth entity:** keep `track` in the instance name for clarity  
and FollowMe path eligibility (e.g. `Track-platform`). Use the `platform` **tag** to  
declare its role; do not rely on bare name matching.

**Without it:** `platform_guideways: []` in the FollowMe export. Natalie cannot route  
to a loading berth. Noelle definition gate fires as a hard stop.

**Recurring failure mode (April 29, 2026):** template drift causes `platform` tag to be
lost from station SKPs during SketchUp editing sessions. Treat any FollowMe export with
zero station platforms as a hard regression. See [Recurring Platform-Loss Guard](#recurring-platform-loss-guard).

---

## CP Detection Priority Chain

`resolve_connection_points` in `jpod_structure_tool.rb` tries three methods in order.
**The first to return results wins.** If a higher-priority method works, lower-priority
methods are never called.

| Priority | Method | Trigger condition |
|---|---|---|
| 1 — Primary | `detect_cps_from_stub_pair_tags` | Any `stub_pair` tagged entities found in the definition |
| 2 — Secondary | `detect_connection_points_from_endings` | No `stub_pair` tags; non-traffic-circle formation |
| 3 — Fallback | `pair_stubs` from `placement_data` | Neither 1 nor 2 found anything |

**Target:** always Priority 1 for stations. Priorities 2 and 3 produce known failures on
station geometry and are only kept for backward compatibility with un-tagged templates.

### How Priority 1 computes the CP

1. Scan all entities tagged `stub_pair` in the definition (recursive, max depth 8).
2. For each tagged entity: collect all vertices **excluding** any nested `dead_end_cap` child.
3. Project vertices onto the radial axis (from formation bounding-box center through stub centroid).
4. Outer group = vertices at max projection → `outer_pt` (centroid, minimum Z).
5. Inner group = vertices at min projection → `inner_pt` (centroid).
6. `tangent = xy_tangent(inner_pt, outer_pt)` — outbound, pointing away from formation.
7. Pair tips that are within `DUAL_TRACK_SPACING × 0.5` to `DUAL_TRACK_SPACING × 1.5` of each other.
8. `gate_ctr = midpoint(outer_pt_a, outer_pt_b)`.
9. CP Z = minimum Z of the outer vertices (bottom-centerline datum).

No cross-track `BEAM_WIDTH / 2` shift is applied since April 29, 2026 — the midpoint of
the two outer tips is already the gate centerline.

**Result stored:** `{ index, center, tangent, half_offset, cap_pt }` in LOCAL coordinates,
JSON-serialised into the `JPods` → `connection_points` entity attribute.

### Paired `stub_pair` midpoint — historical note

Before April 29, 2026 the code applied a `BEAM_WIDTH / 2` (0.25 m) cross-gate correction
because the tagged stub geometry resolved to a lateral face plane rather than the beam
centerline. After aligning the tag to the track centerline geometry, that shift was removed.
If you see CPs offset 0.25 m to one side of the gate midpoint, the tag is on a face-plane
entity rather than the track centerline entity. Fix: retag to the correct entity.

---

## Authoritative CP / FollowMe Datum

The datum for both CPs and FollowMe is the **bottom centerline** of the guideway beam.

- CPs are stored at the bottom-centerline datum of the gate seam.
- `jpod_network.rb` uses the CP to set direction and endpoint anchor, then lifts by `BEAM_DEPTH` to build beam geometry.
- FollowMe is defined on the bottom centerlines of the two built parallel guideways.
- Vehicle runtime advances by millimeters along FollowMe bottom-centerline paths — not beam tops.

---

## Station Identity Requirements

| Requirement | Rule |
|---|---|
| Structure ID | Every station instance must have a unique `Sxxx` attribute (no recycling). Assigned automatically by `Network › Place Structure`. |
| Instance name | Set to `station` for model-tree clarity. |
| Definition name | Set to the station's unique ID (`S001`, `S097`, etc.) for human readability. |
| Manual placement | If inserted without `Place Structure`, the `JPods` → `structure_id` attribute must be set manually before Recompute CPs. |

A SketchUp tag named `station` is **not required** for routing or runtime correctness.
It is useful for visibility-control layering in large models but has no effect on CP
detection, FollowMe export, or Natalie routing.

---

## Station Internal Routing (FollowMe `travel_routes`)

Inside `followme.json`, each station's entry in `structures[]` carries `travel_routes` — the
internal FollowMe lines that move Noras from the gate stubs to the platform berth and back.

Key entries:

| Route name | Meaning |
|---|---|
| `to_center` | Gate → platform berth (standard inbound) |
| `from_center` | Platform berth → gate (standard outbound) |
| `to_center_via_uturn_branch` | Inbound with internal U-turn branch (loop-back required before berth) |
| `u_turn: true` | Terminus station — no outbound connection. Nora arrives and reverses direction internally. |

**Right-hand one-way rule at stations:**  
`|1` is the forward track (station approach direction as authored). `|0` is the return track.  
At a terminus with `u_turn: true`, Nora enters on `|1`, station routes her internally,
she departs on `|0`. A return trip cannot simply reverse in place — it must ride the
parallel track.

---

## Recurring Platform-Loss Guard

Treat **any FollowMe export with zero station platforms as a hard regression**, even if
the file write succeeds.

**Recovery protocol (run every time this recurs):**

1. Open the station SKP. Open SketchUp **Tags** panel. Confirm the `platform` tag exists.
2. Select the loading/unloading berth guideway. Confirm its tag is set to `platform`.
3. Run `Network › Recompute CPs`.
4. Run `JPods Console › Export FollowMe Network JSON`.
5. Check console output. Every station must show `platform_guideways > 0`.
6. Run Noelle validation before any Natalie routing.

If a station still shows `platform_guideways: 0` after step 5, the tag is absent or the
entity is nested deeper than depth 8 (the scan limit). Fix the tag first.

---

## Station Tagging Verification Checklist

Run this before committing a station template or after any SketchUp editing session on a station SKP:

1. Open `templates/track_formations/<station_folder>/model.skp` in SketchUp.
2. Open **Tags** panel. Confirm these tags exist: `stub_pair`, `dead_end_cap`, `platform`.
3. Select each gate's two stub track entities. Confirm tag = `stub_pair`.
4. Select each removable ending-cap entity. Confirm tag = `dead_end_cap` (or rename instance/definition to `dead_end_cap`).
5. Select the loading/unloading berth guideway. Confirm tag = `platform`.
6. Save the SKP.
7. In a model with this formation placed: run `Network › Recompute CPs`.
8. Ruby Console must show: `JPods resolve_connection_points: N CPs from stub_pair tags`.
9. `N` must equal the number of external gates (1 for `station_line_end`, 2 for `station_solar`).
10. CP circles must sit visually centered between the two parallel guideway beams at the cap seam — not tangent to one beam's outside face.
11. Run FollowMe export. Console must show `platform_guideways > 0` for every station.

---

## Known Template Status (May 12, 2026)

| Formation | `stub_pair` | `dead_end_cap` | `platform` | CP source on Recompute |
|---|---|---|---|---|
| `station_solar` | ✓ | ✓ | ✓ | `stub_pair tags` |
| `station_line_end` | ✗ missing | ✗ missing | unknown | `pair_stubs fallback` → trimmed to 1 CP by code guard |
| `JPods_station_container` | unknown | unknown | unknown | unknown |
| `station_parking` | unknown | unknown | unknown | unknown |

**Action required:** Open `station_line_end/model.skp`, add `stub_pair` to gate stubs and
`dead_end_cap` to ending caps, verify `platform` tag on berth guideway. Then audit the
remaining two formations.

**Interim code guard (`jpod_structure_tool.rb → resolve_connection_points`):** if
`model_id` contains `line_end` and `pair_stubs` returns > 1 CP, the code trims to 1
(keeps the outermost) and prints `⚠️ JPods station_line_end: pair_stubs generated N CPs —
trimming to 1`. This guard is unreachable once the template has `stub_pair` tags.

---

## Parking Spur (Design Reserved — Animation Deferred)

Every station will eventually have a **parking spur**: a branch guideway descending from
platform height to street level (Z → terrain) where Noras can be lowered for maintenance,
storage, or future street-level boarding.

**Reserved `followme.json` schema field** (in each station's `structures[]` entry):

```json
"parking_spur": {
  "line_id": "S001_spur|0",
  "street_z_mm": 0.0,
  "status": "reserved"
}
```

**When `status` is `"reserved"`:** Noelle and Natalie must ignore this record entirely.  
**When `status` is `"active"`:** Natalie may route maintenance/storage trips onto the spur.  
Passenger trips may **never** use a spur — Natalie must enforce this.

**Design rules (locked now, implemented later):**

- Spur branches off the platform guideway or station `from_center` route.
- Spur FollowMe line descends at ≤ `MAX_GRADE` (8%) to a `terminal` endpoint at street level.
- Spur endpoint `behavior: "terminal"` in the line record.
- Street-level endpoint carries `parking_spur: true` in the station structures block.
- Natalie treats `parking_spur: true` endpoints as maintenance-only — never on passenger trips.

**Deferred:** no formation template geometry, no animation code, no Natalie routing logic
until issues 1, 5, 6, 7 in `issues.md` are closed.

The field name `parking_spur` is locked here so it cannot be accidentally used for
anything else before the implementation session.

---

## Authoritative Code Files for Station Logic

| File | Owns |
|---|---|
| `jpod_structure_tool.rb` | CP detection (`detect_cps_from_stub_pair_tags`, `detect_connection_points_from_endings`, `pair_stubs`, `resolve_connection_points`), CP storage, Recompute CPs |
| `jpod_guideway.rb` | FollowMe export including `platform_guideways[]` detection per station |
| `jpod_network.rb` | Station bridge building (`build_formation_bridges`) — creates invisible internal FollowMe bridge lines at each gate |
| `noelle.rb` | Network validation including station platform presence gate |
| `natalie.rb` | Trip planning — routes Noras to/from platform guideways; enforces spur exclusion rule |
| `jpod_followme_exporter.rb` | Station-level FollowMe line construction and `structures[]` block |

---

## Cross-References

- Full FollowMe schema: `readmes/followme.md`
- Open issues and deferred features: `readmes/issues.md` (Issue #13 = parking spur)
- CP detection regression guards: `/Users/williamjames/Allie/readmes/sketchup/jpods-cp-regression-guard.md`
- Gap log for recurring failures: `/Users/williamjames/Allie/readmes/sketchup/jpods-gap-log.md`
- Copilot instructions (formation tag rules): `.github/copilot-instructions.md` → Formation Model Tag Requirements
