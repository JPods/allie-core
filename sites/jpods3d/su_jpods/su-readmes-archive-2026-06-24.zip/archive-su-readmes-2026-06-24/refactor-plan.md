# JPods Plugin — Refactor Plan: su_jpods

Date: 2026-05-03
Status: Planning

---

## Goal

Reorganize the plugin from a flat file pile into a clean layered structure.
Every file has one job. Every class has one responsibility. No legacy behavior carried forward.

---

## Target Structure

```
Plugins/
  su_jpods.rb              ← entry point SketchUp discovers (was jpod_loader.rb)
  su_jpods/
    extension.rb           ← SketchUpExtension registration (metadata, icon, version)
    boot.rb                ← ordered require of all subdirs; replaces main.rb

    core/                  ← pure Ruby; no SketchUp API; fully unit-testable
      constants.rb         ← from jpod_constants.rb
      route.rb             ← from noelle.rb (graph, line map, successor logic)
      trip.rb              ← from natalie.rb (BFS planner, trip file writer)
      vehicle.rb           ← from nora.rb (state machine, observation log)
      platform.rb          ← from jpod_platform.rb (slot math, entrance/exit)
      conflict_detector.rb ← from jpod_conflict_detector.rb

    geometry/              ← pure Ruby geometry; no SketchUp API
      path_builder.rb      ← from jpod_path_builder.rb
      curve.rb             ← from my_geom.rb (Bezier, arc helpers)
      terrain_sampler.rb   ← from jpod_terrain.rb
      upright_extruder.rb  ← from upright_extruder.rb (unchanged, rename only)

    sketchup/              ← thin wrappers over SketchUp API
      model_store.rb       ← attribute read/write helpers (get/set_attribute)
      entities_builder.rb  ← guideway geometry creation (from jpod_guideway.rb §build)
      component_factory.rb ← structure/formation loading (from jpod_structure_tool.rb §load)
      layer_manager.rb     ← tag/layer create and assign
      operation.rb         ← model.start_operation / commit wrapper

    network/               ← network graph build and FollowMe export
      builder.rb           ← from jpod_network.rb
      followme_exporter.rb ← FollowMe JSON write (extracted from jpod_guideway.rb)
      cp_detector.rb       ← stub_pair / dead_end_cap CP logic (from jpod_structure_tool.rb)

    agents/                ← Noelle / Natalie / Nora bridge layer
      noelle_bridge.rb     ← from jpod_noelle_bridge.rb
      natalie_bridge.rb    ← from jpod_natalie_bridge.rb
      nora_bridge.rb       ← from jpod_nora_bridge.rb
      oversight.rb         ← from jpod_oversight.rb

    tools/                 ← SketchUp interactive tools (one class per file)
      structure_tool.rb    ← from jpod_structure_tool.rb (placement + UI only)
      connect_tool.rb      ← from jpod_connect_tool.rb
      marker_tool.rb       ← from jpod_marker_tool.rb
      deploy_tool.rb       ← from jpod_deploy_tool.rb
      guideway_designer.rb ← from jpod_guideway_designer.rb

    ui/                    ← menus, toolbar, dialogs
      commands.rb          ← menu registration (from main.rb §register)
      toolbar.rb           ← toolbar icons
      console.rb           ← HtmlDialog task runner (from jpod_console.rb §dialog)
      network_editor.rb    ← HtmlDialog network editor (from jpod_network_editor.rb)
      dialogs/
        console.html        ← unchanged
        network_editor.html ← unchanged

    animation/             ← vehicle motion and camera
      animator.rb          ← from jpod_guideway.rb §animation (largest extraction)
      vehicle_runtime.rb   ← from jpod_vehicle_runtime.rb

    infra/                 ← logging, dispatch, session services
      logging.rb           ← from jpod_logging.rb
      log_writer.rb        ← Kernel#puts tee + log_write (extracted from jpod_console.rb)
      dispatch_server.rb   ← from dispatch_server.rb

    templates/             ← formation SKPs and data (unchanged, move only)
    data/
      defaults.json
```

---

## File Map: Old → New

| Old file | New location | Notes |
|---|---|---|
| `jpod_loader.rb` (Plugins root) | `su_jpods.rb` (Plugins root) | Path updated to `su_jpods/` |
| `main.rb` | `su_jpods/boot.rb` + `su_jpods/ui/commands.rb` | Load loop → boot.rb; menu/observer → commands.rb |
| `jpod_constants.rb` | `su_jpods/core/constants.rb` | Rename only |
| `jpod_path_builder.rb` | `su_jpods/geometry/path_builder.rb` | Rename only |
| `my_geom.rb` | `su_jpods/geometry/curve.rb` | Rename only |
| `jpod_terrain.rb` | `su_jpods/geometry/terrain_sampler.rb` | Rename only |
| `upright_extruder.rb` | `su_jpods/geometry/upright_extruder.rb` | Move only |
| `noelle.rb` | `su_jpods/core/route.rb` | Class rename: `JPods::Route` |
| `natalie.rb` | `su_jpods/core/trip.rb` | Class rename: `JPods::Trip` |
| `nora.rb` | `su_jpods/core/vehicle.rb` | Class rename: `JPods::Vehicle` |
| `jpod_platform.rb` | `su_jpods/core/platform.rb` | Rename only |
| `jpod_conflict_detector.rb` | `su_jpods/core/conflict_detector.rb` | Rename only |
| `jpod_network.rb` | `su_jpods/network/builder.rb` | Rename only |
| `jpod_structure_tool.rb` | Split: `su_jpods/sketchup/cp_detector.rb` + `su_jpods/tools/structure_tool.rb` | CP logic separated from placement tool |
| `jpod_guideway.rb` | Split: `su_jpods/sketchup/entities_builder.rb` + `su_jpods/animation/animator.rb` + `su_jpods/network/followme_exporter.rb` | Largest file — 3-way split |
| `jpod_connect_tool.rb` | `su_jpods/tools/connect_tool.rb` | Rename only |
| `jpod_marker_tool.rb` | `su_jpods/tools/marker_tool.rb` | Rename only |
| `jpod_deploy_tool.rb` | `su_jpods/tools/deploy_tool.rb` | Rename only |
| `jpod_guideway_designer.rb` | `su_jpods/tools/guideway_designer.rb` | Rename only |
| `jpod_network_editor.rb` | `su_jpods/ui/network_editor.rb` | Rename only |
| `jpod_console.rb` | Split: `su_jpods/ui/console.rb` + `su_jpods/infra/log_writer.rb` | Dialog logic separated from Kernel tee |
| `jpod_logging.rb` | `su_jpods/infra/logging.rb` | Rename only |
| `dispatch_server.rb` | `su_jpods/infra/dispatch_server.rb` | Move only |
| `jpod_oversight.rb` | `su_jpods/agents/oversight.rb` | Rename only |
| `jpod_noelle_bridge.rb` | `su_jpods/agents/noelle_bridge.rb` | Rename only |
| `jpod_natalie_bridge.rb` | `su_jpods/agents/natalie_bridge.rb` | Rename only |
| `jpod_nora_bridge.rb` | `su_jpods/agents/nora_bridge.rb` | Rename only |
| `jpod_vehicle_runtime.rb` | `su_jpods/animation/vehicle_runtime.rb` | Rename only |
| `dialogs/console.html` | `su_jpods/ui/dialogs/console.html` | Move only |
| `dialogs/network_editor.html` | `su_jpods/ui/dialogs/network_editor.html` | Move only |
| `templates/` | `su_jpods/templates/` | Move only |

---

## Phases

### Phase 0 — Rename and scaffold (no behavior change)
1. Rename `Plugins/jpod_loader.rb` → `Plugins/su_jpods.rb`; update path to `su_jpods/`
2. Rename folder `Plugins/JPods/` → `Plugins/su_jpods/`
3. Create all subdirectories
4. All existing files stay at root of `su_jpods/` for now; update `boot.rb` load list
5. Verify SketchUp loads cleanly — **stop here if anything breaks**

### Phase 1 — Simple renames (no code changes)
Move and rename the files that map 1:1. In load order:
- constants, terrain, path_builder, curve (my_geom), upright_extruder
- platform, conflict_detector
- network builder, followme_exporter (extract from guideway — carefully)
- tools: connect, marker, deploy, guideway_designer
- agents: oversight, noelle_bridge, natalie_bridge, nora_bridge
- infra: logging, dispatch_server
- ui: network_editor, console html

Verify after each group.

### Phase 2 — Split the large files
Priority order (risk-lowest first):

1. **`jpod_console.rb`** (1867 lines)  
   - Extract Kernel tee + `log_write` → `infra/log_writer.rb`  
   - Leave HtmlDialog + task runner in `ui/console.rb`

2. **`jpod_structure_tool.rb`** (2129 lines)  
   - Extract CP detection methods → `sketchup/cp_detector.rb`  
   - Leave tool activation + placement callbacks in `tools/structure_tool.rb`

3. **`jpod_guideway.rb`** (7494 lines — split last, most risk)  
   - Extract FollowMe export → `network/followme_exporter.rb`  
   - Extract animation timer + vehicle motion → `animation/animator.rb`  
   - Remaining geometry build stays in `sketchup/entities_builder.rb`

### Phase 3 — Core agent rename
- `noelle.rb` → `core/route.rb`, module `JPods::Route`
- `natalie.rb` → `core/trip.rb`, module `JPods::Trip`
- `nora.rb` → `core/vehicle.rb`, module `JPods::Vehicle`
- Update all callers (bridges call these by constant name)

### Phase 4 — main.rb split
- Load loop → `boot.rb`
- Menu/observer registration → `ui/commands.rb`
- `extension.rb` for metadata

---

## Rules for new files

1. One class or module per file. File name matches class name (snake_case).
2. No file longer than 400 lines. If it grows past that, split it.
3. `core/` and `geometry/` files must not `require 'sketchup'`. Pure Ruby only.
4. `sketchup/` files call the API but do not hold business logic.
5. Every public method does one thing. If the method name has "and" in it, split it.
6. No module-body-level side effects — no `Sketchup.add_observer` at file scope. All observer registration goes through `boot.rb` or `ui/commands.rb`.
7. Constants defined once in `core/constants.rb`. No re-`remove_const` patterns.

---

## Do Not Carry Forward

- `main.rb` (replaced by `boot.rb` + `ui/commands.rb`)
- `test_random_trips.rb` (ad-hoc script; move to `hold/` if needed)
- `$jpods_main_loaded`, `$jpods_registered` globals (boot.rb handles load-once via `extension.rb` registered? check)
- `remove_const(:LOG_PATH)` pattern (define once, never redefine)
- Duplicate observer registration patterns
- `alias_method` Kernel patches (keep `prepend` approach)
- Inline `rescue nil` on attribute reads — handle explicitly or let raise
