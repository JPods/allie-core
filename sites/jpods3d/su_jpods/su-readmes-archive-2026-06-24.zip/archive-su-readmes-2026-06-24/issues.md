# JPods Plugin — Known Issues / Future Work

Last updated: 2026-05-12

## Session Handoff (2026-05-12)

- CP direction line added to `JPodNetworkTool#draw`: each CP circle now has a tangent "clock hand" showing outbound direction.
- Bezier preview and built curves confirmed CCW-conforming with the dot-product sign-snap in all 3 sites.
- `station_line_end` template lacks `stub_pair` / `dead_end_cap` tags → pair_stubs fallback generated 2 spurious CPs per instance. Interim guard added to `resolve_connection_points` (trims to 1 CP, warns loudly). Permanent fix: add `stub_pair` tags to `templates/track_formations/station_line_end/model.skp` in SketchUp.

**To fix station_line_end template permanently (do in SketchUp):**
1. Open `templates/track_formations/station_line_end/model.skp`
2. For each of the two parallel gate stub track components: right-click → Entity Info → set Tag to `stub_pair`
3. For each removable end-cap entity at the gate: right-click → Entity Info → set Tag to `dead_end_cap` (or rename instance to `dead_end_cap`)
4. Save. Run Recompute CPs. Console should now print `CPs from stub_pair tags` (not `pair_stubs fallback`).
5. Delete existing CPs on all `station_line_end` instances and Recompute.


- Owner note for next session: **Bill believes behavior may still be affected by changes in the Z-axis of the CP line**. Keep this as an active verification target even when snapshot error reads 0.0 m.

### Next-session verification checklist

1. Re-run with `JPods::Guideway.anim_debug=true` and confirm declared U-turn terminals printed at animation start include `S020.CP0`.
2. At the first jam event, verify route event reason is `no_followme_successor` (not loop/wrap behavior).
3. Change CP-line Z on a controlled test segment and compare resulting vehicle behavior/logs against unchanged FollowMe geometry.
4. If any CP-Z coupling is observed, audit path selection/transition checks for hidden Z dependence beyond FollowMe path sampling.

## Session Note (2026-04-29) — CP Datum + FollowMe Bridge Regression (fixed)

- Symptom A: guideway physically built but gate join looked outside-edge aligned.
- Symptom B: FollowMe omitted the bridge segment between station loop and extruded guideway at stub_pair gates.

Root causes:
- Paired `stub_pair` midpoint correction (`BEAM_WIDTH / 2`) could resolve outward instead of inward.
- FollowMe structure collectors were too strict:
  - required literal structure name `JPods Structure`
  - required entity name containing `track`
  - therefore skipped valid `stub_pair` bridge entities

Fixes:
1. Enforce inward `BEAM_WIDTH / 2` correction for paired `stub_pair` CP midpoint.
2. Expand FollowMe structure scanning to JPods structure candidates (attribute/tag based).
3. Treat `stub_pair`-tagged entities as valid FollowMe path sources in structure collectors.

Do-not-regress checks:
1. Recompute CPs output shows `CPs from stub_pair tags` as source.
2. FollowMe overlay/export includes bridge line at each connected station gate.
3. Join is bottom-centerline to bottom-centerline, never outside-edge to outside-edge.

## Open

| # | Area | Description |
|---|------|-------------|
| 1 | Network Editor | **Build stacks on second click if connection_id unchanged.** `replace: true` erases guideways matching the same `connection_id`, but if the user hits Build twice on the same JSON without clearing the model first, it re-creates on top of itself. Workaround: manually delete old guideways or use Option+Build (add mode). Fix: add a pre-build erase-all step keyed to segment id. |
| 2 | Terrain columns | **terrain_z = 0 when no terrain mesh in model.** `Terrain.elevation_at` returns z=0 when no sandbox/terrain group exists. Columns are placed full CLEARANCE_HEIGHT from z=0. Acceptable for flat terrain; fix when real terrain import is added. |
| 5 | Guideway geometry | **Extrusion smoothness not yet verified.** The `pre_smoothed: true` path skips `insert_horizontal_arcs` in `PathBuilder.build` and uses the dense Bezier sample array directly. The geometry should be smooth but this has not been visually confirmed with a rebuilt network. |
| 6 | Vertical blend | **Smoothstep blend at anchors not yet verified.** The new blend in `apply_vertical_profile` ramps beam Z from the station anchor height with a smoothstep over 40 m (or 35% of segment length). This should eliminate the sharp-angle join at stations. Needs visual confirmation after rebuild. |
| 7 | User interface | **Rework the user interface for end-user clarity and workflow speed.** Current panels/controls need consolidation and cleaner task flow for non-technical users. |
| 8 | Diagnostics / Support | **Add console task: Export Route Support Snapshot.** Provide a one-click task that generates a clean route-support package on demand even if animation has not been started. Include route graph, route diagnostics snapshot, recent log tail, and active project JSON references. |
| 13 | Parking spur — design reserved, animation deferred | **Every station will have a parking spur: a branch guideway that descends from station platform level down to street level (Z → terrain) where Noras can be lowered for maintenance, storage, or street-level boarding.** Design rules: (a) spur branches off the platform guideway or the station's internal `from_center` route; (b) the spur's FollowMe line descends under grade constraints (MAX_GRADE ≤ 8%) to a `terminal` endpoint at street level; (c) spur endpoint tagged `parking_spur: true` in the station's `structures` block inside `followme.json`; (d) Natalie must never route a passenger trip onto a spur — spurs are maintenance/storage routing only. **No animation code until issues 1, 5, 6, 7 are closed.** Formation template work (new spur geometry in station SKPs) and `followme.json` schema field (`parking_spur`) are reserved but not yet built. See `readmes/followme.md` → Parking Spur Reservation. |
| 9 | U-turn / Hairpin cleanup | **Remove all hairpin/U-turn auto-building code.** Users design hairpins as part of their physical network; the plugin should not auto-generate them. Files affected: `jpod_network.rb` (`build_uturn()` method + `u_turns` loop in `build_from_json`), `jpod_network_editor.rb` (u-turn persistence callbacks), `dialogs/network_editor.html` (U-Turns panel + `btn-uturn-add`), `noelle_oversight.py` (u_turns normalization block). Keep `followme_hairpin_item?` detection in `jpod_guideway.rb` — still needed to avoid chaining hairpin-to-hairpin in path building. |
| 10 | Logging | **Startup messages logged twice per restart.** Root cause: `JPods::Logging::TeeIO` wraps `$stdout` and feeds `JPods::Console.log_write`; the `Kernel#puts` patch also calls `log_write`. On startup these two paths fire for the same `puts` call, producing a duplicate entry in `jpod_console.log`. Workaround in place: `log_write` deduplicates consecutive (timestamp, message) pairs so only the first write lands. The `Kernel.prepend(JPodsPutsTee)` patch is structurally immune to double-application but the TeeIO layer still intercepts and calls `log_write` a second time. True fix: remove `log_write` call from TeeIO (let TeeIO feed only the JSON log) and keep Kernel patch as the sole `jpod_console.log` writer. Low priority — dedup suppresses symptom cleanly. |
| 11 | Space conflict — SketchUp headway guard (OC-6) | **SketchUp animation has no minimum headway between Noras on the same line.** The physical fleet uses a zipper merge (`jpod_OS/ezone.py`, `mqtt.py`) to keep pods spaced. The SketchUp animator (`jpod_animator.rb`) does not yet enforce headway. Required before any multi-vehicle classroom demo: add a `MIN_HEADWAY_MM` (≈ 3 500 mm) check before advancing each Nora's position each animation tick. If a follower would violate headway, hold her at current position for that tick. No full zipper simulation needed — a simple hold is sufficient for visual correctness. |
| 12 | Geometry embed strip — production robot OS (OC-5 / deferred) | **FollowMe v2 exports embed `start_mm`/`end_mm` per track.** Correct for classroom use. For physical robot OS deployment, add `"embed_geometry": false` at the top-level envelope. When false, strip geometry fields and write them to a separate `<model>.followme-geometry.json` sidecar. Deferred until first robot OS deployment where memory footprint matters. |

## Closed / Fixed (2026-04-21)

| # | Area | Fix |
|---|------|-----|
| C10 | Animation — vehicles disappear at stations/traffic circles | **Root cause — stitch chain breaks at formation boundaries.** Stations and traffic-circle templates are ComponentInstances; no "JPods Guideway" group spans their interior, so `build_stitched_path` could not chain from one external segment to the next. `pos % total` wrapped to 0, teleporting vehicles. **Fix:** `Network.build_formation_bridges` (called at the end of each network build) creates invisible two-point "JPods Guideway" bridge groups — no drawn geometry, just `beam_path` and `track_index` attributes — spanning each inbound→outbound stub pair inside every formation. The stitch finds them like any other segment. Bridge is skipped if gap < `STITCH_SNAP` (already chainable directly). File: `jpod_network.rb` → `build_formation_bridges` + call in `Network.build`. |

## Closed / Fixed (2026-04-22)

| # | Area | Fix |
|---|------|-----|
| C11 | FollowMe / Animation routing past capped ends | **Root cause — traversal logic followed `next_cid` without checking whether the outbound endpoint was still physically capped.** In final networks, `dead_end_cap` can remain as a future expansion marker, so travel must stop at capped endpoints. **Fix:** added cap-aware traversal gate in `jpod_guideway.rb`. Runtime now scans `dead_end_cap` origins from placed structures, checks each guideway outbound endpoint against cap points, and blocks successor transition when capped. Vehicles U-turn on opposite track when available, else hold at dead end. FollowMe overlay now renders capped outbound endpoints as dead-end styling even when `next_cid` exists. |

## Closed / Fixed (2026-04-20, second pass)

| # | Area | Fix |
|---|------|-----|
| C8 | Guideway shape angled at stations (horizontal) | **Root cause — `apply_vertical_profile` approached anchors at up to MAX_GRADE (8%), producing a kink against the horizontal station centerline.** Fix: after the grade-limited pass, a smoothstep blend forces beam Z to arrive horizontally at each anchor. Blend zone: `min(40 m, 35% of segment length)`. `w = t²(3−2t)` (smoothstep), applied from anchor outward. Endpoints re-pinned to `z0`/`z1` after blend. File: `jpod_path_builder.rb` → `apply_vertical_profile`. |
| C9 | Vehicles no longer animated after Bezier refactor | **Root cause — `start_animation` had `return if @@anim_timer`.** After a network rebuild, the old timer was still running against deleted entities. New vehicles placed after rebuild were never picked up. Fix: replaced `return if @@anim_timer` with `stop_animation if @@anim_timer` so the timer is always restarted fresh. File: `jpod_guideway.rb` → `start_animation`. |

### Diagnostic: animation stitch check (run in Ruby console after placing vehicles)

```ruby
model = Sketchup.active_model
gws = model.entities.select { |e| e.is_a?(Sketchup::Group) && e.name == "JPods Guideway" }
puts "Guideways: #{gws.size}"
gws.each do |gw|
  bp = gw.get_attribute("JPods", "beam_path")
  puts "  GW #{gw.entityID}: beam_path #{bp ? "#{bp.length} chars" : "NIL"}, " \
       "track_idx=#{gw.get_attribute("JPods","track_index","?")}"
  vcount = gw.entities.select { |e|
    e.is_a?(Sketchup::ComponentInstance) && e.get_attribute("JPods","vehicle_id")
  }.size
  puts "    vehicles: #{vcount}"
end
# Check endpoint gaps between adjacent segments (stitch tolerance = STITCH_SNAP = 1.m)
gws.each_with_index do |g1, i|
  bp1 = JSON.parse(g1.get_attribute("JPods","beam_path") || "[]")
  next if bp1.empty?
  last_pt = Geom::Point3d.new(bp1.last)
  gws.each do |g2|
    next if g2 == g1
    bp2 = JSON.parse(g2.get_attribute("JPods","beam_path") || "[]")
    next if bp2.empty?
    next if g2.get_attribute("JPods","track_index") != g1.get_attribute("JPods","track_index")
    gap = last_pt.distance(Geom::Point3d.new(bp2.first))
    puts "  GW#{g1.entityID}→GW#{g2.entityID} gap: #{gap.to_m.round(3)} m" if gap < 5.m
  end
end
```

If gaps > 1 m: increase `STITCH_SNAP` in `jpod_guideway.rb` from `1.m` to `3.m`.

## Closed / Fixed this session (2026-04-20, second pass)

| # | Area | Fix |
|---|------|-----|
| C8 | Guideway shape angled at stations (horizontal) | **Root cause — `apply_vertical_profile` approached anchors at up to MAX_GRADE (8%), producing a kink against the horizontal station centerline.** Fix: after the grade-limited pass, a smoothstep blend forces beam Z to arrive horizontally at each anchor. Blend zone: `min(40 m, 35% of segment length)`. `w = t²(3−2t)` (smoothstep), applied from anchor outward. Endpoints re-pinned to `z0`/`z1` after blend. File: `jpod_path_builder.rb` → `apply_vertical_profile`. |
| C9 | Vehicles no longer animated after Bezier refactor | **Root cause — `start_animation` had `return if @@anim_timer`.** After a network rebuild, the old timer was still running against deleted entities. New vehicles placed after rebuild were never picked up. Fix: replaced `return if @@anim_timer` with `stop_animation if @@anim_timer` so the timer is always restarted fresh. File: `jpod_guideway.rb` → `start_animation`. |

## Closed / Fixed this session (2026-04-20)

| # | Area | Fix |
|---|------|-----|
| C5 | Columns wrong height (T-arm above beam) | **Root cause — scaling instead of positioning.** Code used `scale_z = clearance / t_arm_z` which compressed the column to fit the gap, disconnecting T-arm from beam top whenever terrain varied. **Correct approach:** no scaling. Detect `t_arm_z` from the `CenterGuideway` tag circle in the component (r=26 mm, Z=8.4323 m). Place `col_base.z = beam_pt.z - t_arm_z`. Column is always native size; it sinks into or floats above terrain as needed. `embed_m` in the `column_heights` JSON attribute records depth per column (+ve = underground, -ve = dangling). |
| C6 | Circle detection used wrong radius | `detect_guide_circle_z` searched for r=13.5 mm (a diameter mis-read of 27 mm). Corrected to r=26–27 mm. Also: was searching `CenterCP` (r=27 mm, CP midpoint) instead of `CenterGuideway` (r=26 mm, ×2, the actual weld-point). Fixed search order: `CenterGuideway` → `CenterCP` → radius scan. |
| C7 | Guideway followed straight line between CPs ignoring terrain | `apply_vertical_profile` blended 85% toward a straight baseline between CP heights. A deep valley produced a straight guideway with all columns detached. Replaced with a grade-limited two-pass algorithm: `grade_fwd[i]` = lowest Z reachable from start anchor; `grade_bwd[i]` = same from end anchor; `beam_z = max(floor_z, grade_fwd, grade_bwd, hard_floor_z)`. Valley floor is governed by `PROFILE_MAX_GRADE = 0.08` (8%). |

### Diagnostic pattern for column/circle alignment bugs

If T-arm is ever above or below beam top again, run this in the Ruby console
to see the exact tag names and Z values stored in the component:

```ruby
begin
  defn = Sketchup.active_model.definitions.load(
    "#{Sketchup.find_support_file('Plugins')}/JPods/templates/structures/JPod_support_T/model.skp")
  all_tags = Set.new; all_circles = []
  scan = nil
  scan = lambda do |ents|
    ents.each do |e|
      all_tags << e.layer.name if e.respond_to?(:layer)
      if e.is_a?(Sketchup::Edge)
        c = e.curve
        if c.is_a?(Sketchup::ArcCurve)
          pts = c.edges.flat_map { |ed| ed.vertices.map(&:position) }
          n = pts.size.to_f
          all_circles << { tag: e.layer.name, r_mm: (c.radius.to_m*1000).round(2),
            x: (pts.sum{|p|p.x}/n).to_m.round(4), y: (pts.sum{|p|p.y}/n).to_m.round(4),
            z: (pts.sum{|p|p.z}/n).to_m.round(4) }
        end
      elsif e.is_a?(Sketchup::Group) then scan.call(e.entities)
      elsif e.is_a?(Sketchup::ComponentInstance) then scan.call(e.definition.entities)
      end
    end
  end
  scan.call(defn.entities)
  puts "=== TAGS ==="; all_tags.sort.each { |t| puts "  #{t}" }
  puts "=== CIRCLES ==="; all_circles.uniq.each { |c| puts "  #{c}" }
  puts "t_arm_z: #{JPods::JPodGuideway.detect_guide_circle_z(defn)&.to_m&.round(4)} m"
rescue => e; puts "ERROR: #{e.message}"; end
```

Key rule: `CenterGuideway` Z (currently 8.4323 m) is `t_arm_z`.
Place `col_base.z = beam_pt.z - t_arm_z`. Never scale the column.

## Closed / Fixed this session (2026-04-18)

| # | Area | Fix |
|---|------|-----|
| C1 | Columns crash | `model.definitions.load` inside `start_operation` crashes SketchUp's C layer. Fixed: `preload_structure_definitions` called before every transaction. Same pattern applied to vehicle placement. |
| C2 | Columns invisible | `pushpull` went downward because face normal faced down. Fixed: `f.reverse!` when `f.normal.z < 0`, then `pushpull(height.abs)`. |
| C3 | Columns 0.43 m too high | T arm landed above beam face. Fixed: `base_pt.z = terrain.z - T_ARM_OFFSET` so T arm aligns exactly with beam top. |
| C4 | Build error on empty editor | `JSON.parse(nil)` raised `undefined method '[]' for nil`. Fixed: guard with `.to_s` and Hash type check before reading `data["connections"]`. |

---

## Session notes — 2026-04-27 (formation naming + tomorrow's goal)

### Formation instance naming (traffic circle)

Bill is naming each `stub_pair` sub-component instance explicitly: `pair_stub_0`, `pair_stub_1`, `pair_stub_2`, `pair_stub_3`.

**Verdict:** Good practice for debugging and future stub-index logic. Has **no effect on CP detection** — the plugin detects stubs exclusively by SketchUp tag (`stub_pair`), not by instance name. Tag must remain `stub_pair` on all stubs.

Inner geometry instance names (e.g., `"Track, 2,00m (JPod, arc)"`) are also ignored by the plugin entirely. Only tags and definition names matter.

### Next session goal — 2026-04-28

Get trips running platform to platform:
1. Confirm FollowMe export includes `platform_guideways` entries on both origin and destination stations
2. Confirm Natalie can BFS from origin platform node to destination platform node
3. Confirm Nora can consume the trip and traverse the line sequence without Stop and Review firing
4. Watch console for gate faults before debugging routes — definition gate fires first
5. Get Nora and Natalie parking management working — Noras park at a platform when idle; Natalie tracks which platforms are occupied and routes incoming Noras to a free berth

---

## Session notes — 2026-04-29 (FollowMe regression + recovery)

### Problem observed

FollowMe export regressed to a seemingly valid file with broken station platform metadata:
- `summary.platform_count = 0`
- top-level `platforms` empty
- station blocks present but `platform_guideways` empty

Result:
- Noelle correctly fails definition gate
- Natalie correctly refuses route planning
- Nora cannot receive valid station-to-station trip assignments

### Estimated why we lost it

Recurring SketchUp formation drift during template changes: geometry still exports, but effective `platform` detection path falls out of sync (tag/name placement or nested-entity visibility differences). This is recurring because station templates evolve frequently while FollowMe export remained tolerant of zero-platform writes.

### Recovery actions taken

1. Added strict export-time platform diagnostics in `jpod_guideway.rb`:
  - warning lists every station with `platform_guideways=0`
  - explicit recovery guidance printed in Ruby Console
2. Kept Noelle definition gate strict (no platform = no route).
3. Added startup resilience for SketchUp 2026 Ruby missing WEBrick:
  - `dispatch_server.rb` now disables server gracefully if `webrick` is unavailable
  - `main.rb` now catches `LoadError` in module loading loop so optional module failures do not crash plugin load

### Recovery checklist

1. Verify each station has a loading/unloading guideway marked `platform`.
2. Recompute CPs.
3. Re-export FollowMe.
4. Read strict platform diagnostics in console.
5. Run Noelle validation before Natalie routing.
