Menu Item,Function / Code Called
Place Markers on Terrain,Sketchup.active_model.select_tool(Mostly::JPodMarkerTool.new)
Import Terrain Features,Mostly::Terrain.import_features(Sketchup.active_model)
Deploy Guideway,"Mostly::JPodDeployTool.build_from_selection(model) (if ≥2 markers selected)
or model.select_tool(Mostly::JPodDeployTool.new)"
Clear All Guideways,"Deletes all groups named ""JPods Guideway"" (with confirmation)"
Clear All Markers,"Deletes all groups named ""JPod Marker"" (with confirmation)"
JPods Console,Mostly::Console.open(Sketchup.active_model)
JPods REPL,Mostly::Console.open_repl(Sketchup.active_model)
Run Noelle + Natalie Oversight,"Mostly::Oversight.run_for_model(Sketchup.active_model, source: 'menu')"
Reload Plugin,load __FILE__ + success messagebox