# JPods FollowMe — Authoritative Line Format

Version 1.0 · April 2026

---

## The Single Source of Truth

## Non-Negotiable Geometry Rule (Read First)

> **The most important FollowMe geometry rule is this:**
> At every CP, the authoritative datum is the **bottom centerline of the paired `stub_pair` gate**.
> All exported FollowMe lines, guideway anchors, and runtime distance measurements are defined from that datum.

For paired `stub_pair` gates, CP construction is mandatory and ordered:
1. Find the representative outer tip for each of the two tagged `stub_pair` stubs.
2. Take the midpoint of those two tips.
3. Shift by `BEAM_WIDTH / 2` **inward across the gate** (toward structure origin/interior).
4. Store CP `z` on the bottom-centerline seam datum.

If a build appears edge-to-edge instead of center-to-center, treat it as a **datum regression** and stop to correct CP detection before routing work.

> **FollowMe.json defines the world.**
> CP geometry and guideway geometry exist only to generate FollowMe lines.
> Once FollowMe lines exist, vehicle runtime uses only this file.

All three agents — Noelle, Natalie, and every Nora — read the same file.
Nothing else is authoritative for routing, logging, or planning.

The map and the observed experience log are separate on purpose:
- `followme.json` is the declared network map.
- Nora traversal logs are append-only observations keyed by line ID.
- Noelle may use those observations to assess integrity or health, but Nora logs do not directly overwrite the map.

### Required model state before export

For navigation, trip planning, and animation to work correctly, the SketchUp model must satisfy all of these:

1. Station instances must have unique `Sxxx` structure IDs.
2. Each station must contain at least one detectable platform siding.
3. Guideways must be built so FollowMe line records exist.
4. Vehicles must be assigned only to exported line IDs/trips from the current file.

If this state is incomplete, FollowMe may export with missing platforms or produce no valid vehicle routes.

### Station and platform detection rules

> **Authoritative station documentation is in `readmes/stations.md`.** The rules below
> are kept here as FollowMe-export context. For full tagging requirements and CP detection
> chain, see stations.md.

- `platform` marker is required on the loading/unloading siding in each station.
- Marker detection accepts: SketchUp tag `platform` (preferred), instance name `platform`, or definition name `platform`.
- FollowMe authoring convention: the actual berth guideway instance in SketchUp Entity Info should include `track` in its instance name. Preferred name: `Track-platform`.
- Do not rename the real berth guideway to bare `platform` only. Keep `track` in the instance name and use the `platform` tag to mark its role.
- Detection policy: **tag-first, name-second**. Use tags as authoritative intent markers; use instance/definition names only as fallback guardrails.
- Runtime policy: Nora/Natalie/Noelle execute on declared line identity (`connection_id`, `track_index`, FollowMe `id`), not on SketchUp instance names.
- A SketchUp tag named `station` is optional (useful for visibility/layering), not required for runtime routing.
- Best practice: station instance name `station`, definition name = unique station ID (`S097`, `S098`, ...).

### April 29, 2026 regression lesson (must keep)

Two distinct failures occurred and were fixed:

1. **Guideway join looked edge-aligned**
  - Symptom: new guideway appeared to align outside-edge to outside-edge at station gates.
  - Root cause: paired `stub_pair` midpoint correction used `BEAM_WIDTH / 2` but direction could resolve outward.
  - Fix: force the `BEAM_WIDTH / 2` correction inward (toward structure origin/interior) before storing CP.

2. **FollowMe missing structure bridge at stub_pair gate**
  - Symptom: visible/built guideway looked right, but FollowMe line did not bridge station loop to extruded guideway.
  - Root cause: structure path collector only scanned entities named `JPods Structure` and only entities with `track` in name.
  - Fix: include all JPods structure candidates (attribute/tag-based), and treat `stub_pair` tagged entities as FollowMe path sources.

If either symptom reappears, treat as a CP/FollowMe datum regression and fix geometry export first, then routing.

---

## Why One File, One Format

Three requirements that only a flat line-list satisfies:

| Agent | Needs from FollowMe |
|---|---|
| **Noelle** (network authority) | Complete graph of every line: where it starts, where it ends, what connects to it. No gaps, no inference. |
| **Natalie** (trip planner) | Walk the graph. Assign a sequence of line IDs to each Nora. Must be able to do this without touching geometry. |
| **Nora** (vehicle + logger) | Log her experience per line ID, per trip. Time, speed, anomalies. Append-only. The accumulated log is the team experience base. |

No other representation (polygon mesh, spline set, topology graph embedded in a legacy build file)
satisfies all three without coupling agents together.

---

## File Locations

Generated by: **JPods Console › Export FollowMe Network JSON**

| Artifact | File | Purpose |
|---|---|---|
| FollowMe map | `<model>.followme.json` | **Primary runtime map.** Guideways + structure-internal routes used by Noelle, Natalie, and Nora. |
| Trip files | `trips/<model>.trip.<nora_id>.json` | Per-Nora assigned sequence (platform_start, lines, platform_end). |

Trip files are written to a dedicated `trips/` folder next to the open SketchUp model file.

---

## Trip File Schema (`jpods-trip-v1`)

A trip file is a machine-readable itinerary assigned to one Nora for one trip between two station platforms.

```json
{
  "schema": "jpods-trip-v1",
  "trip_id": "TRIP-OK_LazyE_terrain-NORA_TEST_S097_TO_S098-20260426T170000Z-a1b2c3d4",
  "nora_id": "NORA_TEST_S097_TO_S098",
  "vehicle_template_id": "",
  "platform_start": null,
  "lines": [
    "seg_151545|1"
  ],
  "platform_end": null,
  "line_count": 1,
  "route_note": "S097 exit CP0.2 -> seg_151545|1 (150913mm) -> S098 U-turn",
  "exported_at": "2026-04-26T00:00:00"
}
```

| Field | Type | Meaning |
|---|---|---|
| `schema` | string | Always `"jpods-trip-v1"` — version tag for the consumer |
| `trip_id` | string | Unique trip ID assigned by Natalie (or exporter acting on Natalie's policy) |
| `nora_id` | string | Unique ID for this Nora; matches the log and the filename |
| `vehicle_template_id` | string | Template SKP name (empty = unassigned) |
| `platform_start` | string \| null | FollowMe line ID of the departure platform siding (`null` until platform tags applied) |
| `lines` | array | Ordered sequence of FollowMe line IDs Nora must traverse |
| `platform_end` | string \| null | FollowMe line ID of the arrival platform siding |
| `line_count` | int | `lines.length` — convenience field for consumers |
| `route_note` | string | Human-readable description of the route for debugging |
| `exported_at` | string | ISO 8601 timestamp of export |

**Rules:**
- Every ID in `lines[]` must exist in the current `<model>.followme.json`.
- `platform_start` and `platform_end` are null until `platform` tags are applied to station SKPs and FollowMe is re-exported.
- Trip files are written by `jpod_guideway.rb` `export_trip_json`; the `trips/` folder is auto-created.
- Trip files are read-only for Nora — she appends to her log, not to the trip file.
- `trip_id` must be unique per trip and must not be reused.

### Trip identity and security policy

- Natalie assigns a unique `trip_id` to every itinerary before dispatch.
- Current mode (student planning/evaluation): trip JSON stays human-readable.
- Future production mode: trip payload may be encrypted to make trip tampering harder.
- In both modes, `trip_id` stays clear and stable so Noelle/Natalie/Nora can correlate logs, audits, and replay evidence.

---

## Right-Hand One-Way Rule and Return Routing

JPods guideways are built in parallel pairs. For any segment `seg_XXXXXX`:

| Track index | Direction |
|---|---|
| `seg_XXXXXX\|1` | Forward direction (as authored in the network editor) |
| `seg_XXXXXX\|0` | Reverse direction (the parallel return track) |

Because each track is one-way, **a return trip is not the reverse of the forward trip**. A Nora departing from a terminus station must:

1. Arrive at the terminus on the forward track (`|1`).
2. The terminus station handles the U-turn internally — its `travel_routes` contain an entry with `u_turn: true`.
3. Nora departs on the reverse track (`|0`) back toward her origin.

**Example — OK_LazyE_terrain test trips:**

| Nora | Route | Line IDs | Distance |
|---|---|---|---|
| `NORA_TEST_S097_TO_S098` | S097 → S098 terminus | `seg_151545\|1` | 150,913 mm |
| `NORA_TEST_S098_TO_S097` | S098 terminus → S097 | `seg_151545\|0` | 150,579 mm |

S098 has `u_turn: true` in its `travel_routes` — it is a pure terminus. S097 has `to_center_via_uturn_branch` — a Nora arriving on `|0` enters at CP0.1 and routes internally to the platform center.

---

## Line Record Schema

Each line in the `travel_segment` file is one directional segment of guideway or
structure-internal route.

```json
{
  "id": "C001|0",
  "track_index": 0,
  "length_mm": 45230.0,
  "start": { "x_mm": 12400.0, "y_mm": -3200.0, "z_mm": 5500.0 },
  "end":   { "x_mm": 57630.0, "y_mm": -3200.0, "z_mm": 5500.0 },
  "direction": {
    "ux": 1.0, "uy": 0.0, "uz": 0.0,
    "heading_deg": 0.0
  },
  "connections": {
    "start": {
      "lines":    [{ "id": "C005|1" }],
      "behavior": "continuing"
    },
    "end": {
      "lines":    [{ "id": "C002|0" }, { "id": "C003|0" }],
      "behavior": "diverging"
    },
    "direction": "start_to_end"
  }
}
```

### Field definitions

| Field | Type | Meaning |
|---|---|---|
| `id` | string | `"<connection_id>\|<track_index>"` — unique within the file |
| `track_index` | int | 0 = primary direction; 1 = reverse direction |
| `length_mm` | float | Travel distance in millimeters along the polyline |
| `start` / `end` | object | 3D world coordinates in mm (SketchUp inches × 25.4) |
| `direction.ux/uy/uz` | float | Unit vector start→end |
| `direction.heading_deg` | float | Compass bearing, 0=East, CCW positive |
| `connections.start.lines` | array | Line IDs that arrive at this line's start |
| `connections.end.lines` | array | Line IDs reachable from this line's end |
| `connections.*.behavior` | string | `origin`, `continuing`, `merging`, `diverging`, `terminal` |
| `connections.direction` | string | Always `"start_to_end"` — FollowMe is one-way |

### Endpoint continuity rule (disconnect visibility)

At every endpoint, the file must make adjacency explicit so broken sequences are visible.

- If a line can continue from an endpoint, that endpoint's `connections.*.lines[]` must list the successor/predecessor IDs.
- If an expected line is missing from those arrays, that is a network disconnect and must be treated as a routing fault.
- UI tools should surface these endpoint adjacency lists directly so users can see where sequence breaks occur.

This is the FollowMe equivalent of the EP list in the older robot-map examples (`EPx.lines[]`).

### Behavior values

| Value | Meaning |
|---|---|
| `origin` | No inbound lines — vehicles start here |
| `continuing` | Exactly one predecessor / one successor |
| `merging` | Two or more lines arrive at this start |
| `diverging` | Two or more lines depart from this end |
| `terminal` | No outbound lines — dead end or capped endpoint |

---

## Directionality Rules

1. **FollowMe lines are one-way** — travel direction is always `start → end` as authored.
2. **Counter-clockwise (CCW)** for loops (traffic circles, hairpins).
3. **Turns ≤ 90°** at every join. If no legal continuation exists within this limit, treat as terminal.
4. **Minimum turn diameter 3.5 m** at every join.
5. **Movement unit is millimeters** traveled along accumulated `length_mm`.
6. **Direction authority starts at the start endpoint** (`connections.direction = start_to_end`). Nora must never traverse opposite to authored direction.
7. **Rush-hour direction changes are policy overlays** — they may remap allowed successor lists by time window, but must preserve one-way legality and endpoint continuity.

---

## Agent Responsibilities

### Stop and Review Protocol (Allie, Athena, Noelle, Natalie, Nora)

When the team hits repeated struggle on the same class of issue, agents must escalate immediately.

Rule:
- On the third consecutive failure/block/fault in the same context, emit a mandatory:
  `Stop and Review: fundamentals + root causes before retrying.`

Applies to:
- Allie: repeated user confusion around component definitions or naming.
- Athena: repeated pre-execution task blocks.
- Noelle: repeated FollowMe validation fault runs.
- Natalie: repeated route failure for the same origin→destination context.
- Nora: repeated replan/network-fault/trip-load struggle.

Expected user action:
- Pause retries.
- Verify fundamentals (station identity `Sxxx`, platform marker, required tags, current export freshness).
- Capture root cause in notes/logs.
- Rebuild + re-export before reattempt.

### Allie — Companion (definition gate)

Allie must treat missing/ambiguous station and platform definitions as a stop condition, not a soft warning.

Responsibilities:
- If station IDs, platform guideways, or structure naming are unclear, immediately instruct the user to stop routing/animation work.
- Direct the user to verify component definition and naming first: station identity (`Sxxx`), platform marker (`platform`), and required gate/end tags.
- Require rebuild + FollowMe re-export before resuming Noelle/Natalie operations.

### Noelle — Network Authority

Noelle owns the FollowMe file. She does not modify it at runtime.

Responsibilities:
- Validate the file on load (all `connections.end.lines` IDs must exist in the line list).
- Enforce fail-fast definition checks for station IDs and detectable platform guideways.
- Expose the graph as a queryable structure: given a line ID, return its successors.
- Flag dead ends (terminal lines with no cap explanation).
- Regenerate the file when the SketchUp model is rebuilt.

Noelle does **not** know which vehicle is where. That is Natalie's job.

### Natalie — Trip Planner

Natalie plans trips on Noelle's graph. She does not read geometry.

Responsibilities:
- Accept an origin line ID + destination structure ID.
- Refuse to plan if Noelle's definition gate reports malformed/missing structure definitions.
- Walk the FollowMe graph (BFS/Dijkstra on `connections.end.lines`) to find a path.
- Assign the resulting ordered sequence of line IDs to a Nora as her itinerary.
- Replan on demand if Nora reports an anomaly or delay.

Natalie's output: `{ nora_id: "N003", itinerary: ["C001|0", "C002|0", "C007|0"] }`

### Nora — Vehicle + Logger

Nora executes her itinerary and logs her experience per line.

Responsibilities:
- Track position as `(current_line_id, mm_traveled_on_line)`.
- At line end, advance to next line ID in itinerary; request replan from Natalie if stuck.
- Use wheel encoders as the primary progress signal: distance in mm along the current line.
- Use onboard sensing in the physical system to record actual line experience: travel time, vibration, blockage, merge delay, sensor anomalies, and confidence.
- Log per-line entry on every traversal:

```json
{
  "nora_id": "N003",
  "trip_id": "T00142",
  "line_id": "C001|0",
  "entry_at_ms": 1714000000123,
  "exit_at_ms":  1714000045678,
  "elapsed_ms":  45555,
  "mean_speed_mm_s": 992.4,
  "flags": []
}
```

Nora's log is **append-only**. She never modifies the FollowMe file.
The accumulated log is the team's experience base for Noelle's future planning improvements.

Operational simplification: Nora does not solve free-space path geometry. The physical guideway constrains x/y/z; Nora's runtime problem is line selection plus mm distance traveled on that line.

### Simulated Nora In VS Code

In this plugin workspace, GitHub Copilot may simulate Nora when auditing line sequences, endpoint validity, direction, or network integrity.

Rules for the simulated Nora:
- Treat `followme.json` as the map and line logs as observations about that map.
- Prefer cheap line-ID, endpoint-ID, and next-line validation over expensive simulation.
- Add lightweight inferred checks when useful, but do not assume the excess multi-processor capacity available to physical Noras.
- Physical Noras may fuse cameras, time-of-flight, accelerometers, and other sensors; the simulated Nora here only stands in for route execution reasoning and log review.

---

## Cross-System Coordination

This file format is the contract between four independent systems:

| System | Role | What it reads | What it writes |
|---|---|---|---|
| **SketchUp plugin** (`jpod_guideway.rb`) | Generates the file | SketchUp geometry + `network_definition` in `followme.json` | `<model>.followme.json` |
| **Route-Time browser GUI** | Visualizes + simulates | `<model>.followme.json` | Nothing (read-only) |
| **Physical network (robot OS)** | Nora runs on hardware | `<model>.followme.json` + `trips/<model>.trip.<nora_id>.json` | Nora log entries |
| **Noelle / Natalie services** | Plan + route | `<model>.followme.json` + `trips/<model>.trip.<nora_id>.json` | Nora itineraries |

**No system may invent line IDs.** Every ID referenced in an itinerary, a log entry, or
a visualization must exist verbatim in the current `<model>.followme.json`.

**No system may silently redefine the map from a vehicle log.**
Nora reports observed reality by line ID; Noelle decides whether those observations change network status or require a rebuilt FollowMe map.

**When the SketchUp model changes** (structures moved, connections added/removed):
1. Open the **Network Editor** (`Network › Network Editor & Inspect`), edit `network_definition` as needed, then click **Build**.
2. Re-export via **JPods Console › Export FollowMe Network JSON**.
3. Distribute the new `<model>.followme.json` to all consuming systems before routing resumes.

---

## Parking Spur Reservation (design locked, animation deferred — May 12, 2026)

Every station will eventually have a **parking spur**: a branch guideway descending from
platform height to street level (Z → terrain) where Noras can be lowered for maintenance,
storage, or future street-level boarding.

**Reserved schema field** — each station's entry in `structures[]` will carry:

```json
"parking_spur": {
  "line_id": "S001_spur|0",
  "street_z_mm": 0.0,
  "status": "reserved"
}
```

When `status` is `"reserved"`, Noelle and Natalie must ignore the spur record entirely.
When `status` is `"active"`, Natalie may route maintenance/storage trips onto the spur;
passenger trips may never use a spur (Natalie must enforce this).

**Design rules (recorded now, implemented later):**
- Spur branches off the platform guideway or station `from_center` route.
- Spur FollowMe line descends at ≤ MAX_GRADE (8 %) to a `terminal` endpoint at street level.
- Spur endpoint `behavior: "terminal"` in the line record.
- Street-level endpoint tagged `parking_spur: true` in the station structures block.
- Natalie must treat `parking_spur: true` endpoints as maintenance-only — never on passenger trips.

**Deferred:** no formation template geometry, no animation code, no Natalie routing logic
until issues 1, 5, 6, 7 in `issues.md` are closed. The field name `parking_spur` is
locked so it cannot be accidentally used for anything else in the interim.

---

## What Is Not in FollowMe

| Thing | Where it lives | Why not in FollowMe |
|---|---|---|
| Beam geometry (faces, edges) | SketchUp model | Physical shape; irrelevant to runtime motion |
| CP positions + tangents | `structure_id` attributes on placed instances | Used only during guideway generation |
| Bezier control points | `jpod_network.rb` build step only | Transient; collapses to polyline in FollowMe |
| Vehicle schedules | Natalie's planner | Natalie's job, not Noelle's |
| Fares / demand | Operations layer | Separate concern |
| Parking spur geometry | Station template SKP + deferred build step | Reserved field in schema; not yet built or animated |

---

## File Format — Top-Level Envelope

```json
{
  "model_id": "LazyE",
  "generated_at": "2026-04-25T14:32:00Z",
  "variant": "followme",
  "description": "Guideways between structures plus structure-internal travel routes.",
  "summary": {
    "guideway_count": 12,
    "track_count": 24,
    "structure_route_count": 8,
    "structure_lines": 16
  },
  "guideways": [ ... ],
  "structures": [ ... ],
  "structure_tracks": [ ... ]
}
```

`guideways` contains one entry per connection, each with a `tracks` array of 2 line records
(track_index 0 and 1 — the two directions of travel).

`structures` contains per-structure internal travel routes (platform to guideway transitions).

`structure_tracks` is a flat list of all structure-internal line records (convenience for consumers
that prefer a single flat array).

---

## Generated by

`JPods::JPodGuideway.export_followme_json` in `jpod_guideway.rb`.

Invoke via: **JPods Console › Export FollowMe Network JSON**

The method:
1. Collects all FollowMe polylines from the current SketchUp model.
2. Loads topology from the `network_definition` block inside `<model>.followme.json` (structure IDs, from/to endpoints).
3. Computes adjacency (which lines connect to which) using topology + spatial proximity.
4. Annotates each line record with its `connections` block.
5. Writes `<model>.followme.json` next to the open model.

---

## Recurring Regression Note — April 29, 2026

### Symptom

- FollowMe export succeeds but contains zero detected station platforms:
  - top-level `platforms: []`
  - each station has `platform_guideways: []`
- Noelle definition gate fails on station platform detection.
- Natalie refuses routing before BFS (as designed).

### Estimated root cause

This appears to be a recurring SketchUp formation/tagging drift issue, not a route-graph math failure.
Most likely contributors are:

1. Station formation/template edits that preserve geometry but lose effective `platform` marker visibility at export time.
2. Name/tag mismatches during formation evolution (new station templates and renamed folders).
3. Export-time success criteria that allowed writing a file even when all station platform detections were empty.

### What we changed to recover and harden

1. Added strict export-time diagnostics in `jpod_guideway.rb`:
   - per-station platform detection count
   - explicit warning listing station IDs with zero `platform_guideways`
   - explicit recovery instruction in console output
2. Kept Noelle's definition gate as hard stop for missing station platforms.
3. Added startup hardening for optional dispatch server dependency (`webrick`) so plugin load does not crash when that gem is unavailable.

### Recovery protocol (run every time this recurs)

1. Verify each station formation has a real loading/unloading guideway marked `platform` (tag preferred; name fallback supported).
2. Recompute CPs.
3. Re-export FollowMe.
4. Confirm in console that strict platform diagnostics report all stations with non-zero platform detections.
5. Run Noelle validation before attempting Natalie routing.

---

## OC-5 — Deferred: Production geometry strip (DEFERRED — not yet implemented)

Current exports embed `start_mm` / `end_mm` per track in every line record.
This is intentional for classroom and planning use: one file, open in any text editor, complete.

For production robot OS deployment the geometry embed should be optional:

- Add `"embed_geometry": false` at the top-level envelope.
- When `false`, strip all `start_mm` / `end_mm` fields before writing.
- Keep a separate geometry sidecar (`<model>.followme-geometry.json`) for the animator.

**Status:** Deferred. Design now for classroom. Implement before first robot OS deployment
where memory footprint matters. The `notes[]` field in every v2 export already carries
the reminder: "TODO: consider a separate network geometry library for production deployments."

---

## OC-6 — Space conflict: SketchUp animation + physical fleet (zipper merge)

JPods vehicles must never occupy the same physical space simultaneously. This applies to
both the physical fleet and to the SketchUp animation.

### Physical fleet (already implemented)

The physical pod OS (`jpod_OS/ezone.py`) implements a distributed zipper merge:

- Each Nora publishes her ezone state in MQTT TELEMETRY.
- Noras approaching the same ezone watch each other's entry distance.
- The trailing pod adjusts speed (`ezSpeedAdj`) so spacing is maintained.
- No pod stops — the zipper keeps traffic moving.
- Key files: `jpod_OS/ezone.py`, `jpod_OS/mqtt.py`, `jpod_OS/motor.py`, `jpod_OS/config.py`
- Physical repo: `/Users/williamjames/Documents/08_JPods/03_Technology/JPodsSM_RPi/`

### SketchUp animation (required — not yet implemented)

The animator (`jpod_animator.rb`) must enforce minimum headway between Noras on
the same FollowMe line.

Design requirements:
- Before advancing any Nora, check that no other Nora is within `MIN_HEADWAY_MM`
  of the same line at the same position.
- If a follower would violate headway, hold her at current position for that animation tick.
- `MIN_HEADWAY_MM` should match the physical ezone gap (initially ~3 500 mm — one pod length).
- This is not a full zipper merge simulation; it is a simple headway guard sufficient
  for visual correctness and classroom demonstration.

**Status:** Not yet implemented. Record as a required task before multi-vehicle demos.
Add to `readmes/issues.md`.
