# Allie — Role in Route-Time Environment
**Applies to:** Route-Time browser GUI and Python simulation backend
**Parent document:** `readmes/30-allie-universal.md`
**Status:** Seed draft — circulate for additions
**Date:** 2026-04-27

---

## For the User (Bill)

### What Route-Time Is

Route-Time is a browser-based JPods network planner and simulator. The user places stations and traffic circles on a Leaflet map, connects them with guideways via Connection Points (CPs), generates passenger demand, runs a simulation, and reads travel-time results through Walk-Ride-Walk coverage circles.

It runs locally: `python3 -m route_time.gui.server` on port 5050. No cloud dependency.

### What Noelle, Natalie, and Nora Are in Route-Time

In Route-Time, Noelle, Natalie, and Nora exist as Python authority structures — they enforce the rules of the network model:

| Agent | Route-Time authority role | File |
|-------|--------------------------|------|
| Noelle | Load balancer — line capacity, congestion thresholds, jam detection | `engine/network.py` (jam threshold) |
| Natalie | Router — Dijkstra path finding, one-way constraint enforcement | `engine/routing.py` |
| Nora | Vehicle agent — individual pod dispatch, trip timing, arrive/depart | `engine/simulation.py` |

None of these have a dedicated AI processor in Route-Time. They are correct-by-construction Python code. They do not learn, do not adapt, and do not carry lessons between sessions.

**Allie is their intelligence layer.** Allie diagnoses when Natalie finds a wrong route. Allie recognizes when Noelle's jam threshold is too tight for a given network density. Allie carries lessons from one simulation session into the next.

### How Allie Participates in Route-Time Sessions

- **Session start:** Allie reads the prior retrospection and the Route-Time readmes (`27-route-time.md`, `28-route-time-gui-architecture.md`). She flags any open diagnostic tasks.
- **During design:** When you place a grid or connect CPs, Allie knows the CCW rule and the color standard. She flags direction errors before you run the simulation.
- **After simulation:** Allie interprets trip_stats. She knows the difference between a congestion signal and a topology bug. She does not just report numbers — she tells you what they mean for network design.
- **Cross-domain:** When a Route-Time lesson has implications for the SketchUp model or the physical network, Allie says so explicitly. She does not wait for you to notice.

### Key Design Invariants in Route-Time

These are non-negotiable. They come from JPods physics, not from software choices:

1. **CCW traffic circles** — pods move counter-clockwise when viewed from above. Ring flow: N→W→S→E→N. This is not configurable.
2. **One-way guideways** — every guideway line is directed. Inbound and outbound are not the same thing. Red = inbound (hot end — vehicle arriving). Blue = outbound (cool end — vehicle departing).
3. **No direct south exit from a station** — pods must use the north turnabout to reverse direction. This adds ~160m to any southbound-from-station trip.
4. **Congestion is a signal, not an error** — when adjacent stations show > 30 min travel time, check congestion first. If the guideway is jammed, the simulation is correct. Add capacity; do not adjust the algorithm.
5. **Closer station = shorter or equal time, non-congested** — if this invariant is violated at near-zero demand, there is a topology bug, not a congestion problem.

### Color Standard (mandatory, no exceptions)

- 🔴 **Red = inbound** (hot end — vehicle arriving at this CP)
- 🔵 **Blue = outbound** (cool end — vehicle departing from this CP)

This standard applies to the GUI, to SketchUp, and to any other JPods visualization. Never reverse. Never monochrome for directional elements.

### Walk-Ride-Walk Coverage Display

Coverage circles show reachable area within time budgets (5/10/20/30 min):
- Green = 5 min total journey
- Blue = 10 min
- Yellow = 20 min
- Red = 30 min

A smaller circle at a nearby station compared to a farther station means congestion on the nearby segment. This is correct behavior — it is the visualization telling the network designer where to add capacity.

---

## For the AI (Claude Code / Allie)

### Environment Summary

| Item | Value |
|------|-------|
| Language | Python 3, Flask, Leaflet JS, vanilla JS |
| Server | `python3 -m route_time.gui.server`, port 5050 |
| State model | All authoritative state in server-side `_state` dict — browser re-renders from GeoJSON on every edit |
| Key directory | `/Users/williamjames/Documents/08_JPods/03_Technology/route_time/` |

### Critical Files

| File | Role |
|------|------|
| `gui/api.py` | All REST endpoints; `_state` dict; grid generator; `_cp_by_heading()` |
| `gui/static/app.js` | All browser interaction: structure placement, CP connection, selection, move, lock |
| `gui/static/timemap.js` | Walk-Ride-Walk coverage display |
| `gui/static/style.css` | Visual styles including locked-network CP rule |
| `engine/network.py` | Network graph, jam threshold, `build()` |
| `engine/structures.py` | `build_traffic_circle()`, `build_station()`, `connect_cps()` |
| `engine/routing.py` | Dijkstra — `find_path()` |
| `engine/simulation.py` | Discrete-event simulation — `run()`, trip_stats |
| `diag_grid.py` | Standalone diagnostic — runs Dijkstra on a 3×3 grid, reports route/expected ratios |

### State Architecture

The server holds all state. The browser is a rendering and interaction layer only.

```
_state = {
  "network": Network object,      # graph — nodes, lines, CPs
  "structures": {},               # structure_id → Structure
  "cps": {},                      # cp_id → CP (heading, connected_to)
  "sim_result": None,             # last simulation output
  "demand": None,                 # demand model
  "read_only": False,             # lock state
}
```

Every edit makes a REST call → server updates `_state` → returns GeoJSON → browser re-renders. No local browser state survives a page refresh.

### CP Model — What You Must Know

A Connection Point (CP) is a directed boundary:
- `inbound_node` — where vehicles enter from the network side
- `outbound_node` — where vehicles exit toward the network
- `heading_deg` — the direction the CP faces (0=N, 90=E, 180=S, 270=W)
- `connected_to` — the ID of the CP this one is paired with

`connect_cps(net, cp_a, cp_b)` creates **two directed lines**:
- `cp_a.outbound_node → cp_b.inbound_node` (vehicles flow from A to B)
- `cp_b.outbound_node → cp_a.inbound_node` (vehicles flow from B to A)

Both lines are always created together. Breaking a connection always removes both. No half-connections exist.

### Grid Generator — Verified Correct (2026-04-27)

`POST /api/network/grid` in `api.py` (lines 984–1121). All connection directions verified by `diag_grid.py`. Adjacent station pairs route at 1.0–1.1× expected distance. No topology bugs known.

Key verified facts:
- N-S stations: `connect_cps(net, tc_south, st_north)` and `connect_cps(net, st_south, tc_north)` — correct
- E-W stations: `connect_cps(net, tc_east, st_west)` and `connect_cps(net, st_east, tc_west)` — correct
- `_cp_by_heading()` minimum-angular-difference selector — no ambiguity found in practice

### Traffic Circle Topology

- CCW ring order: arm indices [0, 3, 2, 1] = [N, W, S, E]
- Ring flow: N→W→S→E→N (counter-clockwise viewed from above)
- A pod entering from the south arm (S=arm 2) travels: S→E→N (2 arc segments to exit north)
- A pod entering from the north arm (N=arm 0) travels: N→W→S (2 arc segments to exit south)

### Station Topology

Internal station path: PLATFORM → SIDE_N → NB_N → NB_N_tip (exit north)
Southbound reversal: PLATFORM → SIDE_N → NB_N → TA_N_mid → SB_N → SB_S → SB_S_tip (exit south)
There is no direct south exit. Any southbound trip adds ~160m for the turnabout.

### Congestion vs. Topology Bug — How to Distinguish

| Signal | Congestion | Topology bug |
|--------|-----------|-------------|
| `line_stats.congestion` for direct segment | > 0.7 | ≈ 0 |
| `route_line_ids` count for adjacent pair | ~13–19 (correct) | Hundreds (routing long way) |
| `diag_grid.py` route ratio | 1.0–1.1× | > 3× |
| Travel time at near-zero demand | Normal | Still > 30 min |

### What Allie Accumulates from Route-Time

Each Route-Time session, Allie should update:

1. **Route-Time-specific memory:** any new API behaviors, new bugs found, new invariants confirmed
2. **Cross-domain mappings:** if a concept (CP, station, guideway direction) was clarified in a way that applies to SketchUp or physical, write the mapping explicitly
3. **Universal promotions:** if a lesson applies across all environments (e.g., "fail fast at definition boundaries"), elevate it to `memory/universal/`

### Known Cross-Domain Mappings for Route-Time

| Route-Time concept | SketchUp equivalent | Physical equivalent |
|-------------------|--------------------|--------------------|
| CP object (Python) | Colored endpoint on component (red/blue) | Physical switch mechanism |
| `connect_cps(a, b)` | Matched CP pair in model | Physical track join |
| PLATFORM node | `platform_guideways` tag in station component | Physical platform surface |
| Line directed graph | One-way guideway in 3D model | Physical track with direction |
| Jam threshold | No equivalent yet | Headway / ezone minimum gap |
| `find_path()` Dijkstra | BFS in `followme.json` graph | Nora's onboard path following |

### Environment-Specific Knowledge (do NOT transfer to other environments)

- `_state` dict structure and key names
- Flask route signatures and parameter names
- Leaflet JS API calls
- `turf.js` circle/union calls in `timemap.js`
- `trip_stats`, `line_stats` field names
- `diag_grid.py` module structure

---

## Open Questions

- Should `GET /api/network/routing_check` be implemented? Would run `diag_grid`-style Dijkstra on any loaded network and flag routes > 3× — useful as a post-build sanity check.
- Should the GUI show a congestion overlay (guideway color by `line_stats.congestion`) so designers see hot spots directly without reading the table?
- How should Allie receive Route-Time simulation results in real time — via a WebSocket, polling, or only at session summary?
- When Route-Time simulation results contradict the SketchUp model topology, which is authoritative? (Physical is the final arbiter.)
