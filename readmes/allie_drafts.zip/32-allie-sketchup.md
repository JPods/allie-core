# Allie — Role in SketchUp Plugin Environment
**Applies to:** JPods SketchUp 2026 plugin (`JPods/` folder in SketchUp plugin directory)
**Parent document:** `readmes/30-allie-universal.md`
**Status:** Seed draft — circulate for additions
**Date:** 2026-04-27

---

## For the User (Bill)

### What the SketchUp Plugin Is

The SketchUp plugin is the 3D modeling environment for JPods networks. It allows Bill to draw guideways, place stations, build traffic circles, and export a `followme.json` file that defines the pod route graph. Noelle, Natalie, and Nora then use that graph to plan and execute trips on the physical scale model.

The plugin runs inside SketchUp 2026. It is written in Ruby. GitHub Copilot is the primary AI in the SketchUp environment; Allie is consulted at session start and end.

### What Noelle, Natalie, and Nora Are in SketchUp

In SketchUp, Noelle, Natalie, and Nora are Ruby authority structures — they enforce model correctness rules:

| Agent | SketchUp authority role | File |
|-------|------------------------|------|
| Noelle | Network authority — validates component definitions, detects missing station IDs and platform tags | `noelle.rb` |
| Natalie | Router — BFS path planning on the FollowMe graph; pre-route definition gate | `natalie.rb` |
| Nora | Vehicle agent — consumes the route, logs observations, flags repeated failures | `nora.rb` |
| Athena | Security and escalation — Stop and Review streak escalation | `jpod_console.rb` |

None have a dedicated AI processor. They enforce rules. Allie supplies the intelligence.

### The Fail-Fast Gate

**Silent degradation is the worst failure mode.** A loud fail-fast error at definition time costs 5 seconds. Silent degradation costs a week. This lesson was learned directly: stations were inserted without proper `Sxxx` definition names and `platform` tags. FollowMe export succeeded silently. Routing produced no valid routes. No error was shown. A week was lost.

Every agent now calls `Noelle.component_definition_faults()` before any operation that depends on valid structure definitions. If the gate fires, the operation is refused and the operator receives a canonical corrective message (`definition_hunt_instruction`).

**What the gate checks:**
- Zero structures found in model
- Missing or malformed `Sxxx` definition ID on any station component
- Duplicate `Sxxx` IDs
- Stations with no `platform_guideways` entries

### Stop and Review Protocol

After 3 consecutive failures of the same kind (`STOP_REVIEW_THRESHOLD = 3`), each agent escalates with an explicit "Stop and Review" message. Nora also writes a `stop_and_review` JSONL event to her observation log.

This is not an error. It is a signal: something in the model state is wrong in a persistent way that retrying will not fix. The operator must review the model, not retry the operation.

### How Allie Participates in SketchUp Sessions

- **Session start:** Allie reads `readmes/sketchup/jpods-gap-log.md` (recurring mistake patterns) and the prior retrospection. She flags any unresolved model state issues before Copilot begins.
- **During modeling:** When Copilot is writing Ruby, Allie provides cross-domain context — if a guideway direction decision has consequences for Route-Time simulation or physical pod behavior, she says so.
- **When a gate fires:** Allie diagnoses the pattern. Which formation SKP is missing a tag? Has this same station definition mistake appeared before? She recommends the fix, not just the error.
- **When Stop and Review triggers:** Allie reads the JSONL observation log, identifies the pattern (same origin? same line? same station?), and advises what changed to cause the regression.
- **Session end:** Allie writes the retrospection and updates the gap log with any new recurring mistake patterns.

### Key Design Invariants in SketchUp

1. **CCW guideway direction** — guideways are one-way, counter-clockwise when viewed from above. The SketchUp model must reflect this. Drawing a guideway backwards is not detectable by looking at it — only the direction tag distinguishes inbound from outbound.
2. **Color standard (mandatory)** — red = inbound (vehicle arriving), blue = outbound (vehicle departing). No exceptions. No monochrome for directional elements.
3. **Station identity contract** — every station component definition must have: an `Sxxx` ID on the definition name, at least one `platform` tag inside the component. Without both, Natalie cannot route to it.
4. **FollowMe export is the authority** — the `followme.json` file is what Nora uses. The 3D model is the input; the JSON is the output. If the JSON is wrong, no amount of correct-looking 3D modeling helps.
5. **CP rule** — CPs connect to CPs, never to individual lines. Breaking a connection removes both guideways of the pair. No confirmation dialogs.

---

## For the AI (Copilot / Allie)

### Environment Summary

| Item | Value |
|------|-------|
| Language | Ruby (SketchUp API) |
| Runtime | SketchUp 2026 |
| Primary AI | GitHub Copilot (in SketchUp session) |
| Intelligence layer | Allie (consulted at session start/end, cross-domain flags during session) |
| Key directory | `JPods/` in SketchUp plugin directory |

### Critical Files

| File | Role |
|------|------|
| `noelle.rb` | `component_definition_faults()`, `definition_hunt_instruction()`, Stop and Review streak |
| `natalie.rb` | Pre-route definition gate, BFS route planning, Stop and Review streak |
| `nora.rb` | `note_repeated_struggle()`, `clear_struggle()`, JSONL stop_and_review event |
| `jpod_console.rb` | Athena Stop and Review escalation, main console |
| `readmes/basics.md` | Required tags, runtime contract, station identity requirements |
| `readmes/followme.md` | Required model state, platform detection, Stop and Review protocol |
| `readmes/sketchup/jpods-gap-log.md` | Allie's gap log — recurring mistake patterns |
| `.github/copilot-instructions.md` | Copilot behavior instructions including Allie integration |

### Station Identity Contract

Every station component definition must satisfy all three:

1. **Definition name contains `Sxxx` ID** — e.g., `S001_Boarding_Station`. The `Noelle.component_definition_faults()` gate checks this at prefix.
2. **Contains `platform_guideways` entry** — at least one guideway inside the station component is tagged `platform`. Without this, Natalie cannot route to the station.
3. **No duplicate `Sxxx` IDs** — each station has a unique ID. Duplicates confuse the route graph.

If any station fails this contract, the gate fires before any export or route attempt.

### FollowMe Graph Structure

`followme.json` is a directed graph. Each node is a waypoint on a guideway. Each edge is a directed step from one waypoint to the next, with the step distance in millimeters. Stations are terminal nodes — a route ends when a `platform` node is reached.

**What Natalie's BFS needs:**
- Origin: a node in the graph (usually a platform node of the departure station)
- Destination: a platform node of the arrival station
- Edges: directed — traversing an edge backwards is not permitted

**Common failure modes:**
- Origin node not in graph → silent no-route return (now caught by explicit existence check)
- Destination platform node missing → gate fires before BFS begins
- Disconnected guideway segment → BFS cannot reach destination; logs a route failure

### Recurring Mistake Patterns (gap log — add entries as discovered)

| Pattern | How it presents | How to fix |
|---------|----------------|------------|
| Station component without `Sxxx` ID | Gate fires: "zero Sxxx definitions found" | Rename the component definition in Entity Info |
| Station without platform tag | Gate fires: "station S001 has no platform_guideways" | Add a guideway inside the station, tag it `platform` |
| Guideway drawn in wrong direction | Route goes the long way around; no gate fires | Reverse the guideway direction using the direction tag |
| Disconnected segment after edit | BFS finds no route; no topology error reported | Check the segment endpoints in FollowMe inspector |

### What Allie Accumulates from SketchUp Sessions

Each session, Allie updates:

1. **Gap log** (`readmes/sketchup/jpods-gap-log.md`) — any new recurring mistake pattern
2. **SketchUp-specific memory** — Ruby API behaviors, new gate scenarios, model state patterns
3. **Cross-domain mappings** — if a SketchUp concept clarifies something in Route-Time or physical, write the explicit mapping
4. **Design decisions table** in `noelle.md`, `natalie.md`, `nora.md` — any decision made this session

### Known Cross-Domain Mappings for SketchUp

| SketchUp concept | Route-Time equivalent | Physical equivalent |
|-----------------|----------------------|--------------------|
| `Sxxx` station ID | `structure_id` in network | Station identity tag on physical station hardware |
| `platform_guideways` tag | PLATFORM node in Route-Time network graph | Physical platform surface |
| Colored CP endpoint (red/blue) | CP object with inbound/outbound nodes | Physical switch direction |
| `followme.json` BFS graph | Dijkstra graph in `engine/network.py` | Nora's onboard path map |
| Component definition gate (Noelle) | `diag_grid.py` topology check | Pre-run I2C and MQTT connectivity check |
| Stop and Review at 3 consecutive failures | No equivalent yet | Nora `stop_and_review` JSONL event |

### Environment-Specific Knowledge (do NOT transfer to other environments)

- SketchUp Ruby API calls (`Sketchup.active_model`, `entities`, `component_definitions`)
- `followme.json` format specifics
- FollowMe export sequence
- Copilot instruction format in `.github/copilot-instructions.md`
- JSONL observation log format (Nora's) — physical only

### Authority Boundary for Copilot

When Copilot is working in the SketchUp session:
- Copilot writes Ruby code and works within the SketchUp model
- Allie provides cross-domain context and cross-session pattern recognition
- Copilot does not modify Allie's readmes or memory files
- Allie does not write SketchUp Ruby code directly
- Bill makes all decisions — both Copilot and Allie advise

---

## Open Questions

- What is the right format for Allie to communicate cross-domain flags to Copilot during a SketchUp session? (Currently: session start/end consultation — mid-session flags require Bill to relay them.)
- Should the gap log be in Allie's readmes or in the SketchUp plugin's readmes? (Currently both — Allie's copy is the authoritative one.)
- When Natalie's BFS finds a valid route but Nora physically cannot complete it (track geometry issue), how does that lesson feed back to the SketchUp model? (Currently: Bill observes and corrects manually.)
- What is the correct test for "the model is ready for FollowMe export"? Current gate checks definitions. Are there additional checks needed for track geometry?
