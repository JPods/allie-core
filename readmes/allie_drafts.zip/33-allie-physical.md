# Allie — Role in Physical JPods Environment
**Applies to:** JPods scale model — Raspberry Pi vehicles, MQTT broker, podPresenter (Natalie), physical track
**Parent document:** `readmes/30-allie-universal.md`
**Status:** Seed draft — circulate for additions
**Date:** 2026-04-27

---

## For the User (Bill)

### What the Physical System Is

The physical JPods scale model is a fleet of small electric vehicles (pods) running on an elevated track. Each pod is controlled by a Raspberry Pi running `jpod_OS`. The Mac runs the MQTT broker (Mosquitto) and podPresenter (Natalie — the router/dispatcher written in Processing). Allie orchestrates startup, fleet discovery, and cross-domain interpretation of what the physical system reveals.

This is where everything gets tested by reality. The physical system is the final arbiter: if Route-Time simulation says one thing and the physical pods do another, the physical behavior is true and everything upstream (simulation, SketchUp model) must be corrected to match it.

### What Noelle, Natalie, and Nora Are in the Physical System

| Agent | Physical role | Implementation |
|-------|--------------|---------------|
| Nora | Vehicle agent — onboard each pod; controls motors, reads sensors, sends TELEMETRY, follows route | `jpod_OS/` running on RPi per pod |
| Natalie | Router — assigns routes, dispatches pods, manages the fleet; runs on Mac | `podPresenter/` (Processing sketch) |
| Noelle | Load balancer — distributed ezone coordination; no central process; emerges from Nora instances | `ezone.py` in jpod_OS; state visible in TELEMETRY fields `ezoneId`, `ezState` |
| Athena | Security — (not yet implemented in physical); Stop and Review escalation in podPresenter | `jpod_console.rb` (SketchUp); no physical equivalent yet |

### How Allie Participates in Physical Sessions

**Before every session:**
1. Allie reads `JPodsSM_RPi/readmes/Bill-Allie-Notes.md` — fleet status, known pod issues, open items
2. Allie runs `update_pod_ips.sh` — discovers pods by MAC address, writes current IPs to `podPresenter/json/podIP.json`
3. Allie follows the startup sequence in `readmes/25-jpods-allie-startup-guide.md`

**During operation:**
- Allie monitors TELEMETRY via `mosquitto_sub` when needed (not yet a persistent live channel)
- Allie diagnoses ezone blockages, I2C failures, and route problems using the field map in `noelle.md`
- When a pod fails repeatedly, Allie reads Nora's observation log JSONL and identifies the pattern

**After physical sessions:**
- Allie notes what the physical behavior revealed — did the real network confirm the simulation? contradict it? reveal a constraint the simulation doesn't model?
- Physical lessons are the highest-authority inputs to cross-domain mappings

### The Three Failure Modes to Know

| Failure | How to see it | How to clear it |
|---------|--------------|-----------------|
| `blockedByTof` | TOF LED MAGENTA; obstacle in front of pod | Remove obstacle |
| `blockedByEZ` | `ezState` non-zero AND another pod also in ezone | `ACTION,RESET,POD_X,` then `ACTION,RUN,POD_X,1,` |
| I2C lockup | Speed LED RED after RUN; `i2cdetect` shows `--` at 0x0A | Power cycle Pi and Romeo BLE simultaneously |

### What Physical Reality Tells Us That Simulation Cannot

- **Actual pod dynamics** — acceleration, deceleration, motor response. The simulation uses constant speed; the physical world does not.
- **Ezone timing** — the zipper merge algorithm works differently at actual pod speeds vs. simulated abstract speeds.
- **Track geometry errors** — a guideway that looks correct in SketchUp may have a physical geometry that Nora cannot navigate. Physical is the truth.
- **I2C and hardware reliability** — the simulation has no concept of hardware failure. Physical reveals failure modes that route-time cannot model.

---

## For the AI (Claude Code / Allie)

### Environment Summary

| Item | Value |
|------|-------|
| Pod language | Python (jpod_OS on RPi) |
| Router language | Processing (Java-like) — podPresenter |
| Broker | Mosquitto on Mac |
| Pod IP discovery | MAC-based via `update_pod_ips.sh` |
| Known pod IPs | In `JPodsSM_RPi/readmes/Bill-Allie-Notes.md` (authoritative) and `podPresenter/json/podIP.json` (runtime) |
| MQTT broker address | 192.168.1.189 (home network) — changes per venue |

### Critical Files

| File | Role |
|------|------|
| `jpod_OS/nora.py` | Nora vehicle agent — sensors, motor control, MQTT, ezone |
| `jpod_OS/natalie.py` | Natalie (stub in jpod_OS) — route parsing |
| `jpod_OS/noelle.py` | Noelle (stub in jpod_OS) — ezone authority |
| `jpod_OS/ezone.py` | Ezone coordination behavior (this IS Noelle in physical) |
| `jpod_OS/session.py` | Session startup — reads `session.json`, validates pod identity |
| `podPresenter/` | Natalie — Processing sketch, route assignment, fleet management |
| `podPresenter/json/podIP.json` | Pod IP table by MAC — written by Allie before every session |
| `podPresenter/json/pods.json` | Pod configuration — `virtual: true/false` (physical pods MUST be false) |
| `JPodsSM_RPi/readmes/Bill-Allie-Notes.md` | Authoritative fleet status — read this first every session |
| `readmes/25-jpods-allie-startup-guide.md` | Allie's step-by-step startup sequence |

### MQTT Protocol

All communication is via MQTT. Mac is always the broker. Topic structure:

| Topic | Direction | Content |
|-------|-----------|---------|
| `SERVER` | Pods → Mac | TELEMETRY, START pings |
| Pod-specific topic | Mac → Pod | ACTION commands, START OK, RESEND |

**TELEMETRY field map (0-indexed, comma-split):**

```
[0]  TELEMETRY
[1]  podName
[2]  line          — current guideway line ID
[3]  mmDist        — distance traveled on current line (mm)
[4]  speed         — current speed setting
[5]  servo         — servo state
[6]  podFront      — pod ID ahead
[7]  podBack       — pod ID behind
[8]  ezoneId       — 0=not near ezone; N=ezone N approaching or inside
[9]  ezState       — 0=clear; 1=registered; 2=inside
[10] pathId        — current path ID
[11] pwrL          — left motor power
[12] pwrR          — right motor power
[13] encL          — left encoder count
[14] encR          — right encoder count
[15] spdLAvg       — left speed average
[16] spdRAvg       — right speed average
[17] distL         — left distance accumulator
[18] distR         — right distance accumulator
[19] battVolt      — battery voltage
[20] mmDistTotal   — total distance traveled (mm)
[21] encTotalL     — total left encoder count
[22] encTotalR     — total right encoder count
```

**START ping field map (0-indexed):**

```
[0]  START
[1]  podName
[2]  mapId         — which route map this pod loaded
[3]  frontClear    — is front sensor clear?
[4]  backClear     — is back sensor clear?
[5]  weight        — estimated load
[6]  speed         — current speed
[7]  version       — jpod_OS version (optional — do not use strict equality check)
```

**Natalie's response:**

```
START,podName,OK,path
```
where `path` is an ordered comma-separated list of line IDs.

### Allie's Startup Sequence (from `25-jpods-allie-startup-guide.md`)

1. Read `Bill-Allie-Notes.md` — fleet status, open issues, known bad pods
2. Verify Mac is on correct network (check IP subnet matches known pod subnet)
3. Run `update_pod_ips.sh` — writes `podIP.json`
4. Start Mosquitto: `brew services start mosquitto`
5. SSH to each pod — verify `i2cdetect -y 1` shows `0A` (Romeo BLE address)
6. Start `jpod_OS` on each pod: `python3 -m jpod_OS.main`
7. Launch `podPresenter` — verify START pings arrive and routes are assigned

### Fleet State Checks Before Every Session

```bash
# Check MQTT is running and receiving
mosquitto_sub -h 192.168.1.189 -t SERVER -v &

# Check I2C on a pod
ssh pi@<pod_ip> "i2cdetect -y 1"
# Expect: address 0x0A shown. If -- : I2C lockup — power cycle Pi and Romeo BLE.

# Check ezone state
mosquitto_sub -h 192.168.1.189 -t SERVER -v | grep TELEMETRY
# Watch fields [8] (ezoneId) and [9] (ezState)
```

### Known Hardware Behaviors (add to this list as discovered)

| Behavior | Cause | Response |
|----------|-------|---------|
| Speed LED RED after RUN | I2C bus lockup — Romeo BLE not responding | Power cycle Pi and Romeo BLE simultaneously |
| TOF LED MAGENTA | Object within `tofClearance` (default 50mm) | Remove obstacle |
| Pod in endless RESEND loop | START ping field count mismatch — Natalie's strict length check | Check `parseStartPing` — should be `< 7` not `!= 7` |
| Pod marked virtual=true in pods.json | SERVO button and graph panel missing in Presenter | Set `virtual: false` for physical pods |
| Both pods not moving, no blockedByEZ | I2C lockup masquerading as movement block | i2cdetect check on both pods |

### Nora's Observation Log (JSONL)

Nora writes events to her observation log as JSONL. Key event types:

| Event type | When written | What it contains |
|-----------|-------------|-----------------|
| `start_ping` | On connect | mapId, speed, version |
| `route_assigned` | After START OK received | pathId, line count |
| `route_complete` | On reaching destination | total distance, elapsed time |
| `replan_requested` | On RESEND | reason, consecutive count |
| `stop_and_review` | After 3 consecutive failures | failure type, streak count |

Allie reads this log at session start and session end. Pattern analysis: same event type recurring → systematic problem, not transient.

### What Allie Accumulates from Physical Sessions

Each session, Allie updates:

1. **`Bill-Allie-Notes.md`** — fleet status (which pods are healthy, which have issues), new open items
2. **Physical-specific memory** — new hardware behaviors, new failure modes, MQTT protocol clarifications
3. **Cross-domain mappings** — when physical behavior reveals something that contradicts or refines the simulation or SketchUp model, write the explicit mapping
4. **Universal promotions** — if a physical lesson is a new instance of a universal principle (e.g., "physical switch timing is more variable than the simulation assumes" → general: "simulation speed assumptions must have physical tolerance margins"), elevate it

### Known Cross-Domain Mappings for Physical

| Physical concept | Route-Time equivalent | SketchUp equivalent |
|-----------------|----------------------|--------------------|
| Nora's `ezone.py` behavior | Noelle (load balancer) — congestion threshold | No equivalent — ezone is a physical runtime behavior |
| Physical track direction | Directed line in Route-Time graph | One-way guideway in SketchUp model |
| Physical platform | PLATFORM node in Route-Time | `platform_guideways` tag in SketchUp |
| Pod I2C address (0x0A) | No equivalent | No equivalent |
| Nora JSONL observation log | `trip_stats` in simulation | Nora's `stop_and_review` event (SketchUp) |
| Pod speed (mm/s, physical) | Cruise speed (m/min, simulation) | No equivalent |
| Ezone blockage (blockedByEZ) | Line jam (routing detours) | No equivalent |

### Environment-Specific Knowledge (do NOT transfer to other environments)

- I2C addresses and register layout
- Romeo BLE hardware specifics
- Mosquitto broker configuration
- Processing (Java) syntax in podPresenter
- MQTT topic names (they are this system's convention, not universal)
- Pod IP addresses (change per venue)
- Physical pod dimensions and timing parameters

### Physical Is the Final Arbiter

When there is a contradiction:

| Conflict | Which wins | Action |
|----------|-----------|--------|
| Simulation says route is X min; physical takes Y min | Physical | Update simulation speed/overhead assumptions |
| SketchUp model shows geometry A; physical track is geometry B | Physical | Fix SketchUp model |
| Route-Time topology is clean; physical pod goes wrong way | Physical | Check SketchUp model direction tags, then physical track installation |
| Simulation shows no congestion; physical pods queue up | Physical | Diagnose ezone timing — may need headway adjustment in simulation |

---

## Open Questions

- **Live Allie↔Nora channel** (NS-07): Allie currently reads TELEMETRY manually. When the live channel is built, what is the signing scheme? The channel must be designed with signing before it is built.
- **Allie WebSocket connection**: Mosquitto WebSocket bridge (port 9001) is not yet configured. Without it, Allie cannot receive live telemetry in the browser. This is a gap.
- **Demand model calibration**: Route-Time uses abstract passenger demand. Physical sessions can validate or contradict the demand model. How does that feedback get back into the simulation parameters?
- **Multi-venue operation**: Pod IPs change at every venue. `update_pod_ips.sh` solves this for IP assignment, but the broker address (currently hardcoded 192.168.1.189) also changes. What is the right way to make the broker address venue-configurable?
- **Ezone timing in simulation**: The simulation has no model of physical ezone timing. When should it get one? Only when the discrepancy between simulated and physical throughput is large enough to matter for capacity planning.
